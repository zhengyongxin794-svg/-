/**
 * 站点适配层。
 * 所有选择器都集中在这里，业务逻辑（quiz.js / video.js）只消费适配结果。
 * 用户可以在 options 页用 JSON 追加/覆盖适配规则，无需改代码。
 *
 * 适配规则结构：
 * {
 *   id, name, hosts: ['example.com'],
 *   quiz: {
 *     scope: [...],        // 题目容器（可多个选择器，取命中且最靠视口中心的一个）
 *     stem: [...],         // 题干
 *     optionItem: [...],   // 选项条目
 *     optionLabel: [...],  // 选项字母
 *     optionText: [...]    // 选项正文
 *   },
 *   video: {
 *     player: ['video'],
 *     listItem: [...],     // 视频列表项（章节/小节）
 *     unfinishedText: [...], // 未观看状态文案
 *     finishedText: [...],   // 已完成状态文案
 *     nextButton: [...]      // 平台自带的“下一节”按钮
 *   }
 * }
 */
(function () {
  'use strict';

  const QB = window.QB;

  const GENERIC_QUIZ = {
    scope: [
      '[class*="question-item"]',
      '[class*="questionItem"]',
      '[class*="que-item"]',
      '[class*="topic-item"]',
      '[class*="subject-item"]',
      '[class*="exam-question"]',
      '[class*="question"]',
      '[class*="problem"]',
      '[class*="topic"]'
    ],
    stem: [
      '[class*="question-title"]',
      '[class*="que-title"]',
      '[class*="stem"]',
      '[class*="title"]',
      '[class*="content"]'
    ],
    optionItem: [
      '[class*="option-item"]',
      '[class*="optionItem"]',
      '[class*="answer-item"]',
      '[class*="choice"]',
      '[class*="option"]',
      'label.option'
    ],
    optionLabel: ['[class*="label"]', '[class*="index"]', '[class*="num"]', 'i', 'em', 'b'],
    optionText: ['[class*="option-content"]', '[class*="content"]', '[class*="text"]', 'span']
  };

  const GENERIC_VIDEO = {
    player: ['video'],
    listItem: [
      '[class*="video-item"]',
      '[class*="lesson-item"]',
      '[class*="chapter-item"]',
      '[class*="catalog"] li',
      '[class*="list"] li',
      'li'
    ],
    unfinishedText: ['未观看', '未开始', '未完成', '待学习', '继续学习', '继续观看', '未学完', '0%'],
    finishedText: ['已完成', '已看完', '已学完', '已观看', '100%'],
    nextButton: ['[class*="next"] button', 'button[class*="next"]', '[class*="next-btn"]']
  };

  const BUILTIN_ADAPTERS = [
    {
      id: 'ulearning',
      name: '优学院',
      hosts: ['ulearning.cn', 'ulearning.com', 'ulearning.net', 'ulearning.org'],
      quiz: {
        scope: [
          '.question-item',
          '.que-item',
          '.exam-item',
          '[class*="question-item"]',
          '[class*="que-item"]',
          '.subject-item'
        ],
        stem: ['.question-title', '.que-title', '.stem', '[class*="stem"]', '[class*="title"]'],
        optionItem: [
          '.option-item',
          '.answer-item',
          '.option',
          '[class*="option-item"]',
          '[class*="answer-item"]'
        ],
        optionLabel: ['.option-label', '.label', '.index', 'i', 'em'],
        optionText: ['.option-content', '.content', '.text', 'span']
      },
      video: {
        player: ['video', '#videoPlayer video', '.prism-player video'],
        listItem: [
          '[class*="chapter"] li',
          '[class*="section"] li',
          '[class*="video-item"]',
          '[class*="catalog"] li',
          '.course-list li'
        ],
        unfinishedText: ['未观看', '未开始', '未完成', '继续学习', '0%'],
        finishedText: ['已完成', '已看完', '已学完', '100%'],
        nextButton: ['[class*="next"]']
      }
    },
    {
      id: 'chaoxing',
      name: '超星学习通',
      hosts: ['chaoxing.com', 'edu.cn', 'x.chaoxing.com'],
      quiz: {
        scope: ['.questionLi', '.TiMu', '.question-item', '[class*="questionLi"]', '[class*="TiMu"]'],
        stem: ['.Zy_TItle', '.timu', '[class*="stem"]', '.title'],
        optionItem: ['.Zy_ulTop li', 'ul li', '.option', '[class*="option"]'],
        optionLabel: ['.num_option', 'i', 'em', 'b'],
        optionText: ['a', 'span', '[class*="content"]']
      },
      video: {
        player: ['video', '#video video'],
        listItem: ['[class*="chapter_item"]', '[class*="chapter"] li', '[class*="catalog"] li', '.posCatalog_select'],
        unfinishedText: ['未观看', '未完成', '待学习', '0%'],
        finishedText: ['已完成', '已看完', '100%'],
        nextButton: ['[class*="next"]']
      }
    },
    {
      id: 'zhihuishu',
      name: '智慧树',
      hosts: ['zhihuishu.com', 'zhihuishu.com.cn'],
      quiz: {
        scope: ['.question-item', '.subject-item', '.examPaper_subject', '[class*="question"]'],
        stem: ['.subject-title', '.question-title', '.stem', '.title'],
        optionItem: ['.option-item', '.answer-item', '.option', 'li'],
        optionLabel: ['.label', 'i', 'em', 'span'],
        optionText: ['.content', '.text', 'span']
      },
      video: {
        player: ['video'],
        listItem: ['[class*="video-item"]', '[class*="chapter"] li', '[class*="catalog"] li', 'li'],
        unfinishedText: ['未观看', '未完成', '待学习', '0%'],
        finishedText: ['已完成', '已看完', '100%'],
        nextButton: ['[class*="next"]']
      }
    }
  ];

  function normalizeAdapter(raw, fallback) {
    const adapter = Object.assign({ id: 'custom', name: '自定义', hosts: [] }, raw || {});
    const quiz = Object.assign({}, GENERIC_QUIZ, adapter.quiz || {});
    const video = Object.assign({}, GENERIC_VIDEO, adapter.video || {});
    return {
      id: adapter.id,
      name: adapter.name,
      hosts: adapter.hosts || [],
      quiz: Object.assign({}, fallback ? fallback.quiz : {}, quiz),
      video: Object.assign({}, fallback ? fallback.video : {}, video)
    };
  }

  function hostMatches(hosts, hostname) {
    return (hosts || []).some(function (host) {
      const h = String(host || '').trim().toLowerCase();
      if (!h) return false;
      if (h.indexOf('*') === 0) return hostname.indexOf(h.slice(1)) !== -1;
      return hostname === h || hostname.endsWith('.' + h) || hostname.indexOf(h) !== -1;
    });
  }

  QB.matchAdapter = function (hostnameHost, customAdapters) {
    const hostname = String(hostnameHost || location.hostname || '').toLowerCase();

    // 自定义规则优先级最高（用户可覆盖内置站点）
    const custom = (customAdapters || []).filter(function (item) {
      return item && (item.enabled !== false) && (hostMatches(item.hosts, hostname) || (item.hosts || []).indexOf('*') !== -1);
    });
    if (custom.length) {
      return normalizeAdapter(custom[0], { quiz: GENERIC_QUIZ, video: GENERIC_VIDEO });
    }

    const builtin = BUILTIN_ADAPTERS.find(function (item) {
      return hostMatches(item.hosts, hostname);
    });
    if (builtin) {
      return normalizeAdapter(builtin, { quiz: GENERIC_QUIZ, video: GENERIC_VIDEO });
    }

    return normalizeAdapter(
      { id: 'generic', name: '通用启发式', hosts: ['*'] },
      { quiz: GENERIC_QUIZ, video: GENERIC_VIDEO }
    );
  };

  QB.GENERIC_QUIZ = GENERIC_QUIZ;
  QB.GENERIC_VIDEO = GENERIC_VIDEO;
  QB.BUILTIN_ADAPTERS = BUILTIN_ADAPTERS;
})();
