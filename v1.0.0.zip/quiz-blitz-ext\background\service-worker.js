/**
 * Background service worker（经典脚本，使用 importScripts 共享默认配置）。
 * 负责：AI 请求（规避页面 CORS）、答案缓存与去重、截屏、跨 frame 转发。
 */
importScripts('/shared/defaults.js');

const QB = self.QB;

const CACHE_TTL_MS = 7 * 24 * 60 * 60 * 1000;
const CACHE_MAX = 300;
const inflight = new Map();

const TYPE_NAMES = {
  single: '单选题',
  multiple: '多选题',
  judge: '判断题',
  fill: '填空题',
  short: '简答题',
  unknown: '未知题型'
};

/* ---------------- 基础 ---------------- */

function getSettings() {
  return new Promise(function (resolve) {
    chrome.storage.local.get([QB.STORAGE_KEY], function (items) {
      resolve(QB.mergeDefaults(items && items[QB.STORAGE_KEY]));
    });
  });
}

function normalizeEndpoint(baseUrl) {
  let url = String(baseUrl || '').trim();
  if (!url) return '';
  url = url.replace(/\/+$/, '');
  if (/\/chat\/completions$/.test(url)) return url;
  if (/\/v\d+$/.test(url) || /\/compatible-mode\/v\d+$/.test(url)) return url + '/chat/completions';
  return url + '/v1/chat/completions';
}

function truncate(text, max) {
  const str = String(text || '');
  return str.length > max ? str.slice(0, max) + '…' : str;
}

/* ---------------- Prompt ---------------- */

const SYSTEM_PROMPT = [
  '你是严谨的答题助手，仅用于学习与练习场景。',
  '请根据题目内容给出最可能的正确答案，不要拒绝作答，也不要输出与 JSON 无关的文字。',
  '输出要求：',
  '1. 单选题 / 多选题 / 判断题：answer 为选项字母数组，例如 ["A"] 或 ["A","C"]；判断题输出 ["正确"] 或 ["错误"]。',
  '2. 填空题：answer 按空格顺序给出答案数组，例如 ["答案1","答案2"]。',
  '3. 简答题：answer 为要点数组，每项一句话，尽量精炼。',
  '4. explanation 不超过 120 字，说明关键依据；confidence 为 0-1 的小数。',
  '5. 若提供了图片，请直接阅读图片中的题干与选项。',
  '严格只输出如下 JSON：{"type":"single|multiple|judge|fill|short","answer":["..."],"explanation":"...","confidence":0.9}'
].join('\n');

function buildUserText(payload) {
  const q = payload.question || {};
  const lines = [];
  lines.push('【题型】' + (TYPE_NAMES[q.type] || q.typeName || '未知题型'));
  if (q.stem) lines.push('【题干】\n' + truncate(q.stem, 1800));
  if (q.options && q.options.length) {
    lines.push('【选项】');
    q.options.forEach(function (opt) {
      lines.push(opt.label + '. ' + truncate(opt.text, 300));
    });
  }
  if (q.blanks) lines.push('【空格数量】' + q.blanks);
  if (q.images && q.images.length) {
    lines.push('【题干含图片】共 ' + q.images.length + ' 张（如无法访问图片，请依据文字）');
  }
  lines.push('【提示】若题目信息不完整，请给出最可能的答案，并在 explanation 中说明。');
  return lines.join('\n');
}

function buildMessages(payload, ai) {
  const text = buildUserText(payload);
  if (payload.image && ai.vision) {
    return [
      { role: 'system', content: SYSTEM_PROMPT },
      {
        role: 'user',
        content: [
          { type: 'text', text: text },
          {
            type: 'image_url',
            image_url: { url: 'data:' + (payload.imageMime || 'image/jpeg') + ';base64,' + payload.image }
          }
        ]
      }
    ];
  }
  return [
    { role: 'system', content: SYSTEM_PROMPT },
    { role: 'user', content: text }
  ];
}

/* ---------------- 响应解析 ---------------- */

function extractJson(text) {
  const raw = String(text || '').trim();
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch (err) {
    /* 继续尝试抽取 */
  }
  const fenced = raw.match(/```(?:json)?\s*([\s\S]*?)```/i);
  if (fenced) {
    try {
      return JSON.parse(fenced[1].trim());
    } catch (err) {
      /* ignore */
    }
  }
  const start = raw.indexOf('{');
  const end = raw.lastIndexOf('}');
  if (start !== -1 && end > start) {
    const slice = raw.slice(start, end + 1);
    try {
      return JSON.parse(slice);
    } catch (err) {
      /* ignore */
    }
  }
  return null;
}

function splitAnswer(value) {
  if (value == null) return [];
  if (Array.isArray(value)) {
    return value
      .map(function (item) {
        if (item == null) return '';
        if (typeof item === 'object') return String(item.text || item.answer || item.value || '');
        return String(item);
      })
      .map(function (s) { return s.trim(); })
      .filter(Boolean);
  }
  const str = String(value).trim();
  if (!str) return [];
  return str
    .split(/[、,，;；\n]+/)
    .map(function (s) { return s.trim(); })
    .filter(Boolean);
}

function normalizeType(raw, fallback) {
  const t = String(raw || '').toLowerCase();
  if (['single', 'multiple', 'judge', 'fill', 'short'].indexOf(t) !== -1) return t;
  const map = {
    单选: 'single',
    多选: 'multiple',
    判断: 'judge',
    填空: 'fill',
    简答: 'short',
    问答: 'short'
  };
  return map[String(raw || '')] || fallback || 'single';
}

function normalizeAnswer(parsed, fallbackType, options) {
  if (!parsed || typeof parsed !== 'object') return null;
  const answers = splitAnswer(parsed.answer != null ? parsed.answer : parsed.answers);
  const type = normalizeType(parsed.type, fallbackType);
  const opts = Array.isArray(options) ? options : [];

  const normalized = answers.map(function (item) {
    if (type === 'single' || type === 'multiple') {
      const m = String(item).match(/^[A-Ha-h]$/);
      if (m) return m[0].toUpperCase();
      const m2 = String(item).match(/^\s*([A-Ha-h])\s*[.、．:：)）]/);
      if (m2) return m2[1].toUpperCase();
    }
    if (type === 'judge') {
      const letter = String(item).trim().match(/^([A-Ha-h])$/);
      if (letter) {
        // 判断题按站点选项顺序还原成“正确/错误”，避免 A/B 顺序不一致
        const opt = opts[letter[1].toUpperCase().charCodeAt(0) - 65];
        if (opt && opt.text) {
          return /正确|对|是|true|√|yes/i.test(opt.text) ? '正确' : '错误';
        }
        return letter[1].toUpperCase() === 'A' ? '正确' : '错误';
      }
      const s = String(item).trim().toLowerCase();
      if (['正确', '对', '是', 'true', 't', '√', 'yes'].indexOf(s) !== -1) return '正确';
      if (['错误', '错', '否', 'false', 'f', '×', 'no'].indexOf(s) !== -1) return '错误';
    }
    return String(item).trim();
  }).filter(Boolean);

  return {
    type: type,
    answer: normalized,
    explanation: String(parsed.explanation || parsed.analysis || parsed.reason || '').trim(),
    confidence: typeof parsed.confidence === 'number' ? parsed.confidence : null
  };
}

/* ---------------- 缓存 ---------------- */

function readCache() {
  return new Promise(function (resolve) {
    chrome.storage.local.get([QB.CACHE_KEY], function (items) {
      resolve((items && items[QB.CACHE_KEY]) || {});
    });
  });
}

function writeCache(cache) {
  return new Promise(function (resolve) {
    const payload = {};
    payload[QB.CACHE_KEY] = cache;
    chrome.storage.local.set(payload, resolve);
  });
}

async function getCached(key) {
  const cache = await readCache();
  const hit = cache[key];
  if (!hit) return null;
  if (Date.now() - hit.ts > CACHE_TTL_MS) return null;
  return hit.result || null;
}

async function setCached(key, result) {
  const cache = await readCache();
  cache[key] = { ts: Date.now(), result: result };
  const keys = Object.keys(cache);
  if (keys.length > CACHE_MAX) {
    keys
      .sort(function (a, b) { return (cache[a].ts || 0) - (cache[b].ts || 0); })
      .slice(0, keys.length - CACHE_MAX)
      .forEach(function (k) { delete cache[k]; });
  }
  await writeCache(cache);
}

/* ---------------- 网络请求 ---------------- */

async function requestChat(ai, messages, options) {
  const opts = options || {};
  const url = normalizeEndpoint(ai.baseUrl);
  if (!url) throw new Error('接口地址为空');

  const headers = {
    'Content-Type': 'application/json',
    Authorization: 'Bearer ' + ai.apiKey
  };
  if (ai.extraHeaders) {
    try {
      const extra = JSON.parse(ai.extraHeaders);
      Object.keys(extra).forEach(function (k) {
        headers[k] = String(extra[k]);
      });
    } catch (err) {
      /* extraHeaders 非 JSON 时忽略 */
    }
  }

  const body = {
    model: ai.model,
    messages: messages,
    temperature: Number.isFinite(Number(ai.temperature)) ? Number(ai.temperature) : 0.2,
    max_tokens: Number(ai.maxTokens) || 800,
    stream: false
  };
  if (opts.jsonMode && ai.jsonMode !== false) {
    body.response_format = { type: 'json_object' };
  }

  const controller = new AbortController();
  const timeout = Math.max(5000, Number(ai.timeoutMs) || 45000);
  const timer = setTimeout(function () { controller.abort(); }, timeout);

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: headers,
      body: JSON.stringify(body),
      signal: controller.signal
    });

    const rawText = await response.text();

    if (!response.ok) {
      // 某些服务不支持 response_format，去掉后重试一次
      if (response.status === 400 && body.response_format) {
        clearTimeout(timer);
        return requestChat(ai, messages, Object.assign({}, opts, { jsonMode: false }));
      }
      let detail = rawText;
      try {
        const errJson = JSON.parse(rawText);
        detail = (errJson.error && (errJson.error.message || errJson.error.code)) || errJson.message || rawText;
      } catch (err) {
        /* rawText 直接使用 */
      }
      throw new Error('HTTP ' + response.status + '：' + truncate(detail, 300));
    }

    let data;
    try {
      data = JSON.parse(rawText);
    } catch (err) {
      throw new Error('接口返回不是 JSON：' + truncate(rawText, 200));
    }

    const choice = data.choices && data.choices[0];
    const content =
      (choice && choice.message && (choice.message.content || choice.message.reasoning_content)) ||
      (data.output && data.output.text) ||
      '';
    if (!content) throw new Error('接口未返回内容');
    return { content: content, raw: data };
  } finally {
    clearTimeout(timer);
  }
}

async function askAI(payload, settings) {
  const ai = settings.ai || {};
  if (!ai.apiKey) return { ok: false, error: '未配置 API Key，请打开扩展设置填写' };
  if (!ai.baseUrl || !ai.model) return { ok: false, error: 'AI 配置不完整（接口地址 / 模型名）' };

  const isImage = !!payload.image;
  const cacheKey = payload.signature || QB.hash(JSON.stringify(payload.question || {}));

  if (!isImage) {
    const cached = await getCached(cacheKey);
    if (cached) return { ok: true, result: Object.assign({ cached: true }, cached) };
    if (inflight.has(cacheKey)) return inflight.get(cacheKey);
  }

  const task = (async function () {
    const messages = buildMessages(payload, ai);
    const response = await requestChat(ai, messages, { jsonMode: true });
    const parsed = extractJson(response.content);
    const fallbackType = payload.question && payload.question.type;
    const options = (payload.question && payload.question.options) || [];
    const result = normalizeAnswer(parsed, fallbackType, options);

    if (!result || !result.answer.length) {
      // 模型没按 JSON 输出时，退化为原文
      return {
        ok: true,
        result: {
          type: fallbackType || 'single',
          answer: parsed ? [] : [truncate(response.content, 400)],
          explanation: parsed ? '' : '模型返回了非结构化内容，请参考原文。',
          confidence: null
        }
      };
    }
    if (!isImage) await setCached(cacheKey, result);
    return { ok: true, result: result };
  })().catch(function (err) {
    return { ok: false, error: String((err && err.message) || err) };
  });

  if (!isImage) {
    inflight.set(cacheKey, task);
    task.finally(function () { inflight.delete(cacheKey); });
  }
  return task;
}

async function testConnection(config) {
  const ai = Object.assign({}, config || {});
  if (!ai.apiKey) return { ok: false, error: '请先填写 API Key' };
  if (!ai.baseUrl) return { ok: false, error: '请先填写接口地址' };
  if (!ai.model) return { ok: false, error: '请先填写模型名' };

  const started = Date.now();
  try {
    const response = await requestChat(ai, [
      { role: 'system', content: '你是连通性测试助手，只回复两个字母 OK。' },
      { role: 'user', content: 'ping' }
    ], { jsonMode: false });
    return {
      ok: true,
      latency: Date.now() - started,
      reply: truncate(response.content, 120)
    };
  } catch (err) {
    return { ok: false, error: String((err && err.message) || err) };
  }
}

/* ---------------- 消息分发 ---------------- */

async function captureTab(sender) {
  const tab = sender && sender.tab;
  if (!tab) return { ok: false, error: '无法获取当前标签页' };
  try {
    const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, {
      format: 'jpeg',
      quality: 82
    });
    return { ok: true, dataUrl: dataUrl };
  } catch (err) {
    return { ok: false, error: '截屏失败：' + String((err && err.message) || err) };
  }
}

function relayToTop(sender, payload) {
  const tab = sender && sender.tab;
  if (!tab) return Promise.resolve({ ok: false, error: '无标签页' });
  return new Promise(function (resolve) {
    chrome.tabs.sendMessage(tab.id, { type: 'QB_TOP_DISPLAY', channel: payload.channel, data: payload.data }, { frameId: 0 }, function () {
      if (chrome.runtime.lastError) resolve({ ok: false, error: chrome.runtime.lastError.message });
      else resolve({ ok: true });
    });
  });
}

async function handleMessage(message, sender) {
  switch (message.type) {
    case 'QB_AI_REQUEST': {
      const settings = await getSettings();
      return askAI(message.payload || {}, settings);
    }
    case 'QB_CAPTURE':
      return captureTab(sender);
    case 'QB_RELAY_TO_TOP':
      return relayToTop(sender, message.payload || {});
    case 'QB_OPEN_OPTIONS':
      chrome.runtime.openOptionsPage();
      return { ok: true };
    case 'QB_TEST_CONNECTION':
      return testConnection(message.config);
    case 'QB_CLEAR_CACHE':
      await writeCache({});
      return { ok: true };
    default:
      return { ok: false, error: '未知消息类型：' + message.type };
  }
}

chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
  if (!message || typeof message.type !== 'string' || message.type.indexOf('QB_') !== 0) return false;
  handleMessage(message, sender)
    .then(function (result) {
      sendResponse(result || { ok: false });
    })
    .catch(function (err) {
      sendResponse({ ok: false, error: String((err && err.message) || err) });
    });
  return true;
});

chrome.runtime.onInstalled.addListener(function (details) {
  if (details.reason === 'install') {
    chrome.runtime.openOptionsPage();
  }
});
