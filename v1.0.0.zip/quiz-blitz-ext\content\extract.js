/**
 * 题目提取：从 DOM 中找出“当前正在看的那道题”。
 * 全部基于适配层选择器 + 启发式兜底，不依赖任何具体平台。
 */
(function () {
  'use strict';

  const QB = window.QB;

  const TYPE_NAMES = {
    single: '单选题',
    multiple: '多选题',
    judge: '判断题',
    fill: '填空题',
    short: '简答题'
  };

  const JUDGE_TEXTS = ['正确', '错误', '对', '错', '是', '否', '√', '×', 'true', 'false', 'T', 'F'];

  function sortDom(nodes) {
    return nodes.slice().sort(function (a, b) {
      if (a === b) return 0;
      const pos = a.compareDocumentPosition(b);
      if (pos & Node.DOCUMENT_POSITION_FOLLOWING) return -1;
      if (pos & Node.DOCUMENT_POSITION_PRECEDING) return 1;
      return 0;
    });
  }

  function chooseOptionNodes(candidates) {
    if (!candidates.length) return [];
    const groups = new Map();
    candidates.forEach(function (el) {
      const parent = el.parentElement || el.parentNode;
      if (!parent) return;
      if (!groups.has(parent)) groups.set(parent, []);
      groups.get(parent).push(el);
    });

    let best = null;
    groups.forEach(function (list) {
      if (!best || list.length > best.length) best = list;
    });
    if (best && best.length >= 2) return sortDom(best);

    // 退化：丢弃“包含其它候选项”的外层节点，保留叶子节点
    const leaves = candidates.filter(function (el) {
      return !candidates.some(function (other) {
        return other !== el && el.contains(other);
      });
    });
    return sortDom(leaves.length ? leaves : candidates);
  }

  function textOf(el) {
    if (!el) return '';
    return QB.norm(el.innerText || el.textContent || '');
  }

  /**
   * 识别选项字母。
   * @returns {{label:string, el:Element|null, rawLabel:string}}
   */
  function findLabel(optionEl, selectors, index) {
    for (let i = 0; i < selectors.length; i++) {
      let hit = null;
      try {
        hit = optionEl.querySelector(selectors[i]);
      } catch (err) {
        continue;
      }
      if (hit) {
        const t = QB.norm(hit.textContent || '').replace(/[.、．:：)）\s]/g, '');
        if (/^[A-Ha-h]$/.test(t)) {
          return { label: t.toUpperCase(), el: hit, rawLabel: QB.norm(hit.textContent || '') };
        }
      }
    }
    const raw = textOf(optionEl);
    const m = raw.match(/^([A-Ha-h])\s*[.、．:：、)）]/);
    if (m) return { label: m[1].toUpperCase(), el: null, rawLabel: raw.slice(0, raw.indexOf(m[1]) + 1) };
    const m2 = raw.match(/^[（(]\s*([A-Ha-h])\s*[）)]/);
    if (m2) return { label: m2[1].toUpperCase(), el: null, rawLabel: m2[0] };
    return { label: String.fromCharCode(65 + index), el: null, rawLabel: '' };
  }

  function stripLabelPrefix(text, label) {
    let out = text;
    if (!label) return out;
    const patterns = [
      '^' + label + '\\s*[.、．:：)）]\\s*',
      '^[（(]\\s*' + label + '\\s*[）)]\\s*',
      '^' + label + '\\s+'
    ];
    for (let i = 0; i < patterns.length; i++) {
      const re = new RegExp(patterns[i], 'i');
      if (re.test(out)) {
        out = out.replace(re, '');
        break;
      }
    }
    return out.trim();
  }

  /** @param {object} rules 适配层的 quiz 规则对象 */
  function extractOptionNodes(scope, rules) {
    const candidates = QB.qsaSafe(rules.optionItem, scope).filter(function (el) {
      if (!QB.isVisible(el)) return false;
      const t = textOf(el);
      return t.length > 0 && t.length <= 400;
    });
    const chosen = chooseOptionNodes(candidates).slice(0, 12);

    const result = [];
    const seen = new Set();
    chosen.forEach(function (el, index) {
      const info = findLabel(el, rules.optionLabel, index);
      const label = info.label;
      let text = textOf(el);
      // 先去掉独立的字母元素文本（避免 "A"+"Number" 粘在一起时无法按标点剥离）
      if (info.rawLabel && info.rawLabel.length <= 3 && text.indexOf(info.rawLabel) !== -1) {
        text = text.replace(info.rawLabel, '');
      }
      text = stripLabelPrefix(QB.norm(text), label).replace(/^[\s.、．:：)）]+/, '').trim();
      if (!text) return;
      const key = label + '|' + text;
      if (seen.has(key)) return;
      seen.add(key);
      result.push({ label: label, text: text, el: el });
    });
    return result;
  }

  function deriveStem(scope, rules, optionNodes) {
    let stemEl = null;
    const stemCandidates = QB.qsaSafe(rules.stem, scope);
    for (let i = 0; i < stemCandidates.length; i++) {
      const el = stemCandidates[i];
      if (!QB.isVisible(el)) continue;
      if (optionNodes.some(function (o) { return o.contains(el); })) continue;
      const t = textOf(el);
      if (t.length >= 2) {
        stemEl = el;
        break;
      }
    }
    if (stemEl) return textOf(stemEl).slice(0, 1500);

    let full = textOf(scope);
    optionNodes.forEach(function (o) {
      const t = textOf(o);
      if (t && t.length > 1) full = full.split(t).join(' ');
    });
    return QB.norm(full).slice(0, 1500);
  }

  function detectType(scope, options, stem) {
    let checkbox = 0;
    let radio = 0;
    try {
      checkbox = Array.prototype.filter.call(
        scope.querySelectorAll('input[type="checkbox"]'),
        QB.isVisible
      ).length;
      radio = Array.prototype.filter.call(
        scope.querySelectorAll('input[type="radio"]'),
        QB.isVisible
      ).length;
    } catch (err) {
      /* ignore */
    }

    if (checkbox > 0) return 'multiple';
    if (radio > 0) return 'single';

    if (options.length >= 2) {
      const texts = options.map(function (o) { return o.text.replace(/[。.?？!！\s]/g, ''); });
      const allJudge = texts.every(function (t) {
        return JUDGE_TEXTS.some(function (k) { return t === k || t.indexOf(k) === 0; });
      });
      if (options.length === 2 && allJudge) return 'judge';
      return 'single';
    }

    if (/_{3,}|（\s*）|\(\s*\)/.test(stem)) return 'fill';
    let textarea = 0;
    let textInput = 0;
    try {
      textarea = scope.querySelectorAll('textarea').length;
      textInput = Array.prototype.filter.call(
        scope.querySelectorAll('input[type="text"], input:not([type])'),
        function (el) { return QB.isVisible(el) && !el.closest('[class*="search"]'); }
      ).length;
    } catch (err) {
      /* ignore */
    }
    if (textarea > 0) return 'short';
    if (textInput > 0) return 'fill';
    return options.length ? 'single' : 'short';
  }

  function countBlanks(scope, stem, type) {
    let n = 0;
    try {
      n += (stem.match(/_{3,}/g) || []).length;
      n += scope.querySelectorAll('[class*="blank"]').length;
      n += scope.querySelectorAll('input[type="text"]').length;
    } catch (err) {
      /* ignore */
    }
    if (type === 'fill' && n === 0) n = 1;
    return Math.min(n, 10);
  }

  function collectImages(scope) {
    const out = [];
    try {
      scope.querySelectorAll('img').forEach(function (img) {
        if (out.length >= 3) return;
        if (!QB.isVisible(img)) return;
        const src = img.currentSrc || img.src;
        if (!src || src.indexOf('data:') === 0) return;
        const rect = img.getBoundingClientRect();
        if (rect.width < 60 || rect.height < 40) return;
        out.push(src);
      });
    } catch (err) {
      /* ignore */
    }
    return out;
  }

  function collectScopes(rules) {
    let scopes = QB.qsaSafe(rules.scope).filter(QB.isVisible);
    if (!scopes.length) return [];
    // 视口中心优先，且限制候选数量，避免大页面上的无效计算
    scopes.sort(function (a, b) {
      return QB.rectDistanceToCenter(a) - QB.rectDistanceToCenter(b);
    });
    scopes = scopes.slice(0, 12);
    const valid = scopes.filter(function (scope) {
      const opts = extractOptionNodes(scope, rules);
      if (opts.length >= 2) return true;
      const text = textOf(scope);
      return text.length >= 8 && /_{3,}|（\s*）/.test(text);
    });
    // 内层优先：如果某个候选容器包含另一个候选容器，丢弃外层
    return valid.filter(function (scope) {
      return !valid.some(function (other) {
        return other !== scope && scope.contains(other);
      });
    });
  }

  /**
   * 提取当前题目
   * @returns {{ok:boolean, reason?:string, type?:string, typeName?:string, stem?:string,
   *            options?:Array, blanks?:number, images?:Array, scopeEl?:Element, signature?:string}}
   */
  QB.extractQuestion = function (adapter, settings) {
    const minStem = (settings && settings.quiz && settings.quiz.minStemLength) || 4;
    const rules = (adapter && adapter.quiz) || QB.GENERIC_QUIZ;
    const scopes = collectScopes(rules);
    if (!scopes.length) return { ok: false, reason: '未找到题目容器' };

    let best = null;
    scopes.forEach(function (scope) {
      const options = extractOptionNodes(scope, rules);
      const stem = deriveStem(scope, rules, options.map(function (o) { return o.el; }));
      if (options.length < 2 && QB.norm(stem).length < minStem) return;
      const score = options.length * 10 + Math.min(stem.length, 200) / 100;
      const distance = QB.rectDistanceToCenter(scope);
      if (
        !best ||
        score > best.score + 0.5 ||
        (Math.abs(score - best.score) <= 0.5 && distance < best.distance)
      ) {
        best = { scope: scope, options: options, stem: stem, score: score, distance: distance };
      }
    });

    if (!best) return { ok: false, reason: '题目缺少题干或选项' };

    const type = detectType(best.scope, best.options, best.stem);
    const stem = QB.norm(best.stem);
    if (stem.length < minStem && best.options.length < 2) {
      return { ok: false, reason: '题干过短' };
    }

    const signature = QB.hash(
      [stem, type]
        .concat(best.options.map(function (o) { return o.label + ':' + o.text; }))
        .join('|')
    );

    return {
      ok: true,
      type: type,
      typeName: TYPE_NAMES[type] || '未知题型',
      stem: stem,
      options: best.options,
      blanks: countBlanks(best.scope, stem, type),
      images: collectImages(best.scope),
      scopeEl: best.scope,
      signature: signature
    };
  };

  QB.TYPE_NAMES = TYPE_NAMES;
})();
