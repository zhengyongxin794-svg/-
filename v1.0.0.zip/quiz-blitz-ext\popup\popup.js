(function () {
  'use strict';

  const QB = window.QB;
  let settings = QB.mergeDefaults(null);

  const els = {
    status: document.getElementById('status'),
    quizEnabled: document.getElementById('quizEnabled'),
    videoEnabled: document.getElementById('videoEnabled'),
    speed: document.getElementById('speed'),
    speedVal: document.getElementById('speedVal'),
    reanalyze: document.getElementById('reanalyze'),
    nextVideo: document.getElementById('nextVideo'),
    openOptions: document.getElementById('openOptions')
  };

  function save(patch) {
    settings = QB.mergeDefaults(Object.assign({}, settings, patch));
    const payload = {};
    payload[QB.STORAGE_KEY] = settings;
    chrome.storage.local.set(payload);
  }

  function setStatus(text, kind) {
    els.status.textContent = text;
    els.status.className = 'status' + (kind ? ' ' + kind : '');
  }

  function renderSpeed(value) {
    const speed = Number(value) || 1;
    els.speed.value = String(speed);
    els.speedVal.textContent = speed.toFixed(1) + 'x';
  }

  function getActiveTab() {
    return new Promise(function (resolve) {
      chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        resolve(tabs && tabs[0]);
      });
    });
  }

  function broadcast(channel, payload) {
    return getActiveTab().then(function (tab) {
      if (!tab || !tab.id) return false;
      try {
        chrome.tabs.sendMessage(
          tab.id,
          { type: 'QB_BROADCAST', channel: channel, payload: payload || {} },
          function () {
            void chrome.runtime.lastError;
          }
        );
        return true;
      } catch (err) {
        return false;
      }
    });
  }

  function refreshStatus() {
    const ai = settings.ai;
    if (!ai.apiKey || !ai.baseUrl || !ai.model) {
      setStatus('未配置 AI 接口。点击下方按钮填写接口地址、Key 与模型名。', 'warn');
      return;
    }
    setStatus('已配置：' + ai.model + ' · ' + (ai.vision ? '含视觉兜底' : '纯文本'), 'ok');
  }

  function bind() {
    els.quizEnabled.addEventListener('change', function () {
      save({ quiz: Object.assign({}, settings.quiz, { enabled: els.quizEnabled.checked }) });
      broadcast(els.quizEnabled.checked ? 'panel-show' : 'panel-hide');
    });

    els.videoEnabled.addEventListener('change', function () {
      save({ video: Object.assign({}, settings.video, { enabled: els.videoEnabled.checked }) });
    });

    els.speed.addEventListener('input', function () {
      renderSpeed(els.speed.value);
    });

    els.speed.addEventListener('change', function () {
      const speed = Number(els.speed.value);
      save({ video: Object.assign({}, settings.video, { speed: speed, autoSpeed: true }) });
      broadcast('video-cmd', { cmd: 'set-speed', value: speed });
    });

    document.querySelectorAll('.chips button').forEach(function (btn) {
      btn.addEventListener('click', function () {
        const speed = Number(btn.dataset.speed);
        renderSpeed(speed);
        save({ video: Object.assign({}, settings.video, { speed: speed, autoSpeed: true }) });
        broadcast('video-cmd', { cmd: 'set-speed', value: speed });
      });
    });

    els.reanalyze.addEventListener('click', function () {
      broadcast('panel-show');
      broadcast('quiz-reanalyze');
      window.close();
    });

    els.nextVideo.addEventListener('click', function () {
      broadcast('video-cmd', { cmd: 'next' });
      window.close();
    });

    els.openOptions.addEventListener('click', function () {
      chrome.runtime.openOptionsPage();
      window.close();
    });
  }

  chrome.storage.local.get([QB.STORAGE_KEY], function (items) {
    settings = QB.mergeDefaults(items && items[QB.STORAGE_KEY]);
    els.quizEnabled.checked = !!settings.quiz.enabled;
    els.videoEnabled.checked = !!settings.video.enabled;
    renderSpeed(settings.video.speed);
    bind();
    refreshStatus();
  });
})();
