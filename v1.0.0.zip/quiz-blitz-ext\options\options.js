(function () {
  'use strict';

  const QB = window.QB;
  const $ = function (id) { return document.getElementById(id); };

  let settings = QB.mergeDefaults(null);

  const BUILTIN_NAMES = ['优学院', '超星学习通', '智慧树', '通用启发式（任意站点）'];

  function num(id, fallback) {
    const value = Number($(id).value);
    return Number.isFinite(value) ? value : fallback;
  }

  function setResult(el, text, kind) {
    el.textContent = text;
    el.className = 'result' + (kind ? ' ' + kind : '');
  }

  function flashSaved() {
    const hint = $('saveHint');
    hint.textContent = '已保存 ' + new Date().toLocaleTimeString();
  }

  function collect() {
    return {
      ai: {
        baseUrl: $('aiBaseUrl').value.trim(),
        apiKey: $('aiApiKey').value.trim(),
        model: $('aiModel').value.trim(),
        temperature: Math.min(2, Math.max(0, num('aiTemperature', 0.2))),
        maxTokens: Math.max(64, num('aiMaxTokens', 800)),
        timeoutMs: Math.max(5000, num('aiTimeoutMs', 45000)),
        extraHeaders: $('aiExtraHeaders').value.trim(),
        jsonMode: $('aiJsonMode').checked,
        vision: $('aiVision').checked
      },
      quiz: {
        enabled: $('quizEnabled').checked,
        autoAnalyze: $('quizAuto').checked,
        showExplanation: $('quizExplain').checked,
        highlightOptions: $('quizHighlight').checked,
        screenshotFallback: $('quizScreenshot').checked,
        debounceMs: Math.max(200, num('quizDebounce', 800)),
        minStemLength: Math.max(2, num('quizMinStem', 4)),
        panel: settings.quiz.panel
      },
      video: {
        enabled: $('videoEnabled').checked,
        autoSpeed: $('videoAutoSpeed').checked,
        speed: Math.min(15, Math.max(1, num('videoSpeed', 8))),
        maxSpeed: 15,
        autoNext: $('videoAutoNext').checked,
        nextDelayMs: Math.max(300, num('videoNextDelay', 1500)),
        enforceRate: $('videoEnforce').checked,
        autoPlay: $('videoAutoPlay').checked
      },
      customAdapters: settings.customAdapters,
      debug: $('debugMode').checked
    };
  }

  function persist() {
    const next = collect();
    chrome.storage.local.get([QB.STORAGE_KEY], function (items) {
      const current = QB.mergeDefaults(items && items[QB.STORAGE_KEY]);
      // 保留悬浮面板的位置 / 折叠状态（可能刚被用户拖动过）
      next.quiz.panel = current.quiz.panel;
      settings = QB.mergeDefaults(next);
      const payload = {};
      payload[QB.STORAGE_KEY] = settings;
      chrome.storage.local.set(payload, flashSaved);
    });
    updateSpeedLabel();
  }

  const persistDebounced = debounce(persist, 400);

  function debounce(fn, wait) {
    let timer = null;
    return function () {
      if (timer) clearTimeout(timer);
      timer = setTimeout(function () {
        timer = null;
        fn();
      }, wait);
    };
  }

  function applyToForm(data) {
    $('aiBaseUrl').value = data.ai.baseUrl || '';
    $('aiApiKey').value = data.ai.apiKey || '';
    $('aiModel').value = data.ai.model || '';
    $('aiTemperature').value = data.ai.temperature;
    $('aiMaxTokens').value = data.ai.maxTokens;
    $('aiTimeoutMs').value = data.ai.timeoutMs;
    $('aiExtraHeaders').value = data.ai.extraHeaders || '';
    $('aiJsonMode').checked = !!data.ai.jsonMode;
    $('aiVision').checked = !!data.ai.vision;

    $('quizEnabled').checked = !!data.quiz.enabled;
    $('quizAuto').checked = !!data.quiz.autoAnalyze;
    $('quizExplain').checked = !!data.quiz.showExplanation;
    $('quizHighlight').checked = !!data.quiz.highlightOptions;
    $('quizScreenshot').checked = !!data.quiz.screenshotFallback;
    $('quizDebounce').value = data.quiz.debounceMs;
    $('quizMinStem').value = data.quiz.minStemLength;
    $('debugMode').checked = !!data.debug;

    $('videoEnabled').checked = !!data.video.enabled;
    $('videoAutoSpeed').checked = !!data.video.autoSpeed;
    $('videoSpeed').value = data.video.speed;
    $('videoAutoNext').checked = !!data.video.autoNext;
    $('videoNextDelay').value = data.video.nextDelayMs;
    $('videoEnforce').checked = !!data.video.enforceRate;
    $('videoAutoPlay').checked = !!data.video.autoPlay;

    $('adaptersJson').value = (data.customAdapters && data.customAdapters.length)
      ? JSON.stringify(data.customAdapters, null, 2)
      : '';

    updateSpeedLabel();
  }

  function updateSpeedLabel() {
    $('speedLabel').textContent = Number($('videoSpeed').value).toFixed(1) + 'x';
  }

  function parseAdapters() {
    const raw = $('adaptersJson').value.trim();
    if (!raw) return { ok: true, value: [] };
    let parsed;
    try {
      parsed = JSON.parse(raw);
    } catch (err) {
      return { ok: false, error: 'JSON 语法错误：' + err.message };
    }
    if (!Array.isArray(parsed)) return { ok: false, error: '必须是一个数组 []' };
    for (let i = 0; i < parsed.length; i++) {
      const item = parsed[i];
      if (!item || typeof item !== 'object') return { ok: false, error: '第 ' + (i + 1) + ' 项不是对象' };
      if (!Array.isArray(item.hosts) || !item.hosts.length) {
        return { ok: false, error: '第 ' + (i + 1) + ' 项缺少 hosts 数组（域名）' };
      }
      if (!item.quiz || typeof item.quiz !== 'object') {
        return { ok: false, error: '第 ' + (i + 1) + ' 项缺少 quiz 规则对象' };
      }
    }
    return { ok: true, value: parsed };
  }

  function bindAdapters() {
    $('adaptersJson').addEventListener('input', function () {
      const result = parseAdapters();
      if (!result.ok) {
        setResult($('adapterMsg'), result.error, 'err');
        return;
      }
      setResult($('adapterMsg'), '已保存 ' + result.value.length + ' 条自定义规则', 'ok');
      settings.customAdapters = result.value;
      persist();
    });

    $('btnValidate').addEventListener('click', function () {
      const result = parseAdapters();
      if (result.ok) {
        setResult($('adapterMsg'), 'JSON 合法，共 ' + result.value.length + ' 条规则（修改后自动保存）', 'ok');
      } else {
        setResult($('adapterMsg'), result.error, 'err');
      }
    });

    $('btnExample').addEventListener('click', function () {
      $('adaptersJson').value = JSON.stringify([
        {
          id: 'my-platform',
          name: '我的平台',
          hosts: ['example.com'],
          quiz: {
            scope: ['.q-item'],
            stem: ['.q-title'],
            optionItem: ['.q-option'],
            optionLabel: ['.idx'],
            optionText: ['.txt']
          },
          video: {
            player: ['video'],
            listItem: ['[class*=video-item]'],
            unfinishedText: ['未观看', '未完成'],
            finishedText: ['已完成']
          }
        }
      ], null, 2);
      $('adaptersJson').dispatchEvent(new Event('input'));
    });
  }

  function bindForm() {
    const ids = [
      'aiBaseUrl', 'aiApiKey', 'aiModel', 'aiTemperature', 'aiMaxTokens',
      'aiTimeoutMs', 'aiExtraHeaders', 'aiJsonMode', 'aiVision',
      'quizEnabled', 'quizAuto', 'quizExplain', 'quizHighlight', 'quizScreenshot',
      'quizDebounce', 'quizMinStem', 'debugMode',
      'videoEnabled', 'videoAutoSpeed', 'videoSpeed', 'videoAutoNext',
      'videoNextDelay', 'videoEnforce', 'videoAutoPlay'
    ];
    ids.forEach(function (id) {
      const el = $(id);
      el.addEventListener('input', function () {
        if (id === 'videoSpeed') updateSpeedLabel();
        persistDebounced();
      });
      el.addEventListener('change', persistDebounced);
    });

    $('toggleKey').addEventListener('click', function () {
      const input = $('aiApiKey');
      const show = input.type === 'password';
      input.type = show ? 'text' : 'password';
      this.textContent = show ? '隐藏' : '显示';
    });
  }

  function bindTest() {
    $('btnTest').addEventListener('click', function () {
      const btn = this;
      const resultEl = $('testResult');
      setResult(resultEl, '正在测试…');
      btn.disabled = true;

      chrome.runtime.sendMessage(
        { type: 'QB_TEST_CONNECTION', config: collect().ai },
        function (res) {
          btn.disabled = false;
          if (chrome.runtime.lastError) {
            setResult(resultEl, '测试失败：' + chrome.runtime.lastError.message, 'err');
            return;
          }
          if (res && res.ok) {
            setResult(resultEl, '连接成功 · ' + res.latency + 'ms · 回复：' + (res.reply || '（空）'), 'ok');
          } else {
            setResult(resultEl, '测试失败：' + ((res && res.error) || '未知错误'), 'err');
          }
        }
      );
    });
  }

  function bindData() {
    $('btnClearCache').addEventListener('click', function () {
      const el = $('dataMsg');
      chrome.runtime.sendMessage({ type: 'QB_CLEAR_CACHE' }, function (res) {
        if (res && res.ok) setResult(el, '答案缓存已清空', 'ok');
        else setResult(el, '清空失败', 'err');
      });
    });

    $('btnExport').addEventListener('click', function () {
      const blob = new Blob([JSON.stringify(settings, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'quiz-blitz-settings.json';
      a.click();
      URL.revokeObjectURL(url);
      setResult($('dataMsg'), '已导出配置文件', 'ok');
    });

    $('btnImport').addEventListener('click', function () {
      $('importFile').click();
    });

    $('importFile').addEventListener('change', function () {
      const file = this.files && this.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = function () {
        try {
          const parsed = JSON.parse(String(reader.result || '{}'));
          settings = QB.mergeDefaults(parsed);
          applyToForm(settings);
          persist();
          setResult($('dataMsg'), '配置已导入', 'ok');
        } catch (err) {
          setResult($('dataMsg'), '导入失败：' + err.message, 'err');
        }
        $('importFile').value = '';
      };
      reader.readAsText(file);
    });

    $('btnReset').addEventListener('click', function () {
      if (!confirm('确定恢复默认配置？AI Key 与自定义适配规则都会被清空。')) return;
      settings = QB.mergeDefaults(null);
      applyToForm(settings);
      persist();
      setResult($('dataMsg'), '已恢复默认配置', 'ok');
    });
  }

  function renderBuiltin() {
    const wrap = $('builtinList');
    BUILTIN_NAMES.forEach(function (name) {
      const span = document.createElement('span');
      span.textContent = name;
      wrap.appendChild(span);
    });
  }

  chrome.storage.local.get([QB.STORAGE_KEY], function (items) {
    settings = QB.mergeDefaults(items && items[QB.STORAGE_KEY]);
    applyToForm(settings);
    renderBuiltin();
    bindForm();
    bindAdapters();
    bindTest();
    bindData();
  });
})();
