/**
 * 答题引擎：监听题目切换 -> 提取 -> 请求 AI -> 渲染面板 + 页面选项高亮。
 * 子 frame 的题目同样会被解析，结果转发给顶层 frame 的面板展示。
 */
(function () {
  'use strict';

  const QB = window.QB;
  const HL_ATTR = 'data-qb-highlight';

  const state = {
    adapter: null,
    enabled: true,
    lastSig: '',
    lastQuestion: null,
    lastResult: null,
    analyzing: false,
    attemptSig: '',
    timer: null,
    maxTimer: null,
    observer: null,
    pollTimer: null,
    hlNodes: [],
    started: false,
    lastShotAt: 0,
    lastAiSnapshot: undefined
  };

  function panelAvailable() {
    return QB.isTopFrame && QB.Panel.isMounted();
  }

  function setStatus(text, kind) {
    if (panelAvailable()) QB.Panel.setStatus(text, kind);
    relay({ channel: 'quiz-status', data: { text: text, kind: kind || '' } });
  }

  /** 子 frame -> background -> 顶层 frame */
  function relay(payload) {
    if (QB.isTopFrame) return;
    QB.send({ type: 'QB_RELAY_TO_TOP', payload: payload });
  }

  function modelTag() {
    const ai = QB.settings.ai || {};
    if (!ai.apiKey || !ai.model) return '未配置 AI（点设置）';
    return ai.model;
  }

  function refreshPanelChrome() {
    if (!panelAvailable()) return;
    QB.Panel.setModelTag(modelTag());
    QB.Panel.setQuizEnabled(state.enabled);
  }

  /* ---------------- 高亮 ---------------- */

  function clearHighlight() {
    state.hlNodes.forEach(function (item) {
      const el = item.el;
      if (!el || !el.style) return;
      el.style.removeProperty('outline');
      el.style.removeProperty('outline-offset');
      el.style.removeProperty('box-shadow');
      el.style.removeProperty('background-color');
      el.removeAttribute(HL_ATTR);
    });
    state.hlNodes = [];
  }

  function highlightOptions(q, answers) {
    clearHighlight();
    if (!QB.settings.quiz.highlightOptions) return;
    const targets = (q.options || []).filter(function (opt) {
      return answers.some(function (ans) {
        return matchAnswer(opt, ans);
      });
    });
    targets.forEach(function (opt) {
      const el = opt.el;
      if (!el || !el.style) return;
      el.style.setProperty('outline', '2px solid #22c55e', 'important');
      el.style.setProperty('outline-offset', '2px', 'important');
      el.style.setProperty('box-shadow', '0 0 0 4px rgba(34,197,94,.16)', 'important');
      el.style.setProperty('background-color', 'rgba(34,197,94,.10)', 'important');
      el.setAttribute(HL_ATTR, '1');
      state.hlNodes.push({ el: el });
    });
  }

  function normalizeAnswerText(text) {
    return String(text || '')
      .replace(/^[A-Ha-h]\s*[.、．:：)）]\s*/, '')
      .replace(/[。.?？!！\s"“”'‘’]/g, '')
      .toLowerCase();
  }

  function matchAnswer(opt, ans) {
    const raw = String(ans == null ? '' : ans).trim();
    if (!raw) return false;
    if (/^[A-Ha-h]$/.test(raw)) return raw.toUpperCase() === String(opt.label).toUpperCase();
    const a = normalizeAnswerText(raw);
    const b = normalizeAnswerText(opt.text);
    if (!a || !b) return false;
    return a === b || b.indexOf(a) === 0 || a.indexOf(b) === 0;
  }

  /* ---------------- 面板渲染 ---------------- */

  function renderResult(q, result) {
    const answers = (result.answer || []).map(String).filter(Boolean);
    const longType = q.type === 'fill' || q.type === 'short';
    const label = answers.join(longType ? '\n' : '、');

    let answerText;
    if (!answers.length) {
      answerText = '（模型未给出明确答案）';
    } else if (longType) {
      answerText = label;
    } else {
      answerText = '答案：' + label;
    }

    const hints = (q.options || []).map(function (opt) {
      return {
        label: opt.label,
        text: opt.text,
        hit: answers.some(function (ans) { return matchAnswer(opt, ans); })
      };
    });

    if (panelAvailable()) {
      if (QB.Panel.isCollapsed() && !QB.settings.quiz.panel.hidden) QB.Panel.expand();
      QB.Panel.setBadge(q.typeName);
      QB.Panel.setStem(q.stem);
      QB.Panel.setAnswer({
        answerText: answerText,
        isLong: longType,
        hints: hints,
        explanation: result.explanation || ''
      });
      QB.Panel.setStatus(
        result.cached ? '已命中本地缓存' : '分析完成' + (result.confidence ? '（置信度 ' + Math.round(result.confidence * 100) + '%）' : ''),
        'ok'
      );
    } else {
      relay({
        channel: 'quiz-result',
        data: {
          typeName: q.typeName,
          stem: q.stem,
          answerText: answerText,
          isLong: longType,
          hints: hints,
          explanation: result.explanation || '',
          status: '来自内嵌框架的分析结果'
        }
      });
    }

    highlightOptions(q, answers);
  }

  function showError(message) {
    if (panelAvailable()) QB.Panel.setStatus(message, 'err');
    else relay({ channel: 'quiz-status', data: { text: message, kind: 'err' } });
  }

  /* ---------------- 分析 ---------------- */

  function buildPayload(q) {
    return {
      type: 'quiz',
      signature: q.signature,
      question: {
        type: q.type,
        typeName: q.typeName,
        stem: q.stem,
        options: (q.options || []).map(function (o) {
          return { label: o.label, text: o.text };
        }),
        blanks: q.blanks || 0,
        images: (q.images || []).slice(0, 3)
      }
    };
  }

  async function askAI(payload) {
    const ai = QB.settings.ai || {};
    if (!ai.apiKey) {
      showError('未配置 API Key，请点击面板底部“设置”填写');
      return null;
    }
    if (!ai.baseUrl || !ai.model) {
      showError('AI 配置不完整：请填写接口地址与模型名');
      return null;
    }
    return QB.send({ type: 'QB_AI_REQUEST', payload: payload });
  }

  async function analyze(question, options) {
    const opts = options || {};
    if (!state.enabled) return;
    if (state.analyzing) return;
    const q = question || state.lastQuestion;
    if (!q) return;

    state.analyzing = true;
    state.attemptSig = q.signature;
    setStatus('AI 分析中…', 'loading');
    if (panelAvailable()) {
      QB.Panel.setBadge(q.typeName);
      QB.Panel.setStem(q.stem);
    }

    try {
      const response = await askAI(buildPayload(q));
      if (!response) return;

      if (!response.ok) {
        showError('请求失败：' + (response.error || '未知错误'));
        return;
      }
      if (state.lastSig && state.lastSig !== q.signature && !opts.force) {
        // 分析期间题目已切换，丢弃过期结果
        return;
      }
      state.lastResult = response.result;
      renderResult(q, response.result);
    } catch (err) {
      showError('出错：' + String(err && err.message ? err.message : err));
    } finally {
      state.analyzing = false;
      if (state.lastSig && state.attemptSig && state.lastSig !== state.attemptSig) {
        // 期间切题了，再跑一次
        scheduleInspect(200);
      }
    }
  }

  /* ---------------- 截图兜底 ---------------- */

  async function captureQuestionImage(scopeEl) {
    const shot = await QB.send({ type: 'QB_CAPTURE' });
    if (!shot.ok || !shot.dataUrl) throw new Error(shot.error || '无法截屏');

    const img = new Image();
    img.src = shot.dataUrl;
    await img.decode();

    const dpr = img.width / Math.max(1, window.innerWidth);
    let rect = null;
    if (scopeEl && scopeEl.isConnected) {
      const r = scopeEl.getBoundingClientRect();
      if (r.width > 40 && r.height > 20) rect = r;
    }
    if (!rect) {
      rect = {
        left: 0,
        top: 0,
        width: window.innerWidth,
        height: window.innerHeight
      };
    }

    let left = Math.max(0, rect.left);
    let top = Math.max(0, rect.top);
    let width = Math.min(rect.width, window.innerWidth - left);
    let height = Math.min(rect.height, window.innerHeight - top);
    if (width < 40 || height < 20) {
      left = 0;
      top = 0;
      width = window.innerWidth;
      height = window.innerHeight;
    }

    const sx = Math.round(left * dpr);
    const sy = Math.round(top * dpr);
    const sw = Math.min(Math.round(width * dpr), img.width - sx);
    const sh = Math.min(Math.round(height * dpr), img.height - sy);

    const maxSide = 1400;
    const scale = Math.min(1, maxSide / Math.max(sw, sh));
    const canvas = document.createElement('canvas');
    canvas.width = Math.max(1, Math.round(sw * scale));
    canvas.height = Math.max(1, Math.round(sh * scale));
    const ctx = canvas.getContext('2d');
    ctx.drawImage(img, sx, sy, sw, sh, 0, 0, canvas.width, canvas.height);

    const dataUrl = canvas.toDataURL('image/jpeg', 0.82);
    return dataUrl.split(',')[1] || '';
  }

  async function analyzeByScreenshot(scopeEl) {
    if (!QB.settings.ai.vision || !QB.settings.quiz.screenshotFallback) {
      showError('未识别到题目文本。可在设置页开启“视觉兜底 + 截图识别”（需支持图片的模型）');
      return;
    }
    if (state.analyzing) return;
    const now = Date.now();
    if (now - state.lastShotAt < 8000) return;

    state.analyzing = true;
    setStatus('未识别到文本，正在截图识别…', 'loading');
    try {
      const base64 = await captureQuestionImage(scopeEl);
      state.lastShotAt = now;
      const response = await QB.send({
        type: 'QB_AI_REQUEST',
        payload: {
          type: 'quiz',
          signature: 'shot-' + Math.floor(now / 60000),
          question: {
            type: 'unknown',
            typeName: '截图识别',
            stem: '请根据图片内容作答',
            options: [],
            blanks: 0
          },
          image: base64,
          imageMime: 'image/jpeg'
        }
      });
      if (!response || !response.ok) {
        showError('截图识别失败：' + ((response && response.error) || '未知错误'));
        return;
      }
      const q = state.lastQuestion || { type: 'unknown', typeName: '截图识别', stem: '', options: [] };
      renderResult(q, response.result);
    } catch (err) {
      showError('截图识别出错：' + String(err && err.message ? err.message : err));
    } finally {
      state.analyzing = false;
    }
  }

  /* ---------------- 题目巡检 ---------------- */

  function scheduleInspect(delay) {
    if (state.timer) clearTimeout(state.timer);
    state.timer = setTimeout(function () {
      state.timer = null;
      inspect(false);
    }, delay == null ? 300 : delay);
  }

  function inspect(force) {
    if (!state.enabled || !state.adapter) {
      clearHighlight();
      return;
    }
    if (document.hidden && !force) return;

    const q = QB.extractQuestion(state.adapter, QB.settings);
    if (!q.ok) {
      if (force) {
        analyzeByScreenshot(null);
      } else if (state.lastQuestion) {
        // 页面可能只是暂时重渲染，保留上次结果
      }
      return;
    }

    if (q.signature === state.lastSig && !force) {
      if (!state.lastResult && !state.analyzing && QB.settings.quiz.autoAnalyze && state.attemptSig !== q.signature) {
        scheduleAnalyze(q);
      }
      return;
    }

    // 新题目
    state.lastSig = q.signature;
    state.lastQuestion = q;
    state.lastResult = null;
    state.attemptSig = '';
    if (state.maxTimer) {
      clearTimeout(state.maxTimer);
      state.maxTimer = null;
    }
    clearHighlight();

    if (QB.isTopFrame && !QB.Panel.isMounted()) QB.Panel.init();

    if (panelAvailable()) {
      QB.Panel.clearAnswer();
      QB.Panel.setBadge(q.typeName);
      QB.Panel.setStem(q.stem);
    }

    if (QB.settings.quiz.autoAnalyze) {
      setStatus('已识别题目，准备分析…', 'loading');
      scheduleAnalyze(q);
    } else {
      setStatus('已识别题目，点击 ↻ 或 Alt+R 分析', '');
    }
  }

  function scheduleAnalyze(q) {
    if (state.timer) clearTimeout(state.timer);
    const wait = Math.max(200, Number(QB.settings.quiz.debounceMs) || 800);
    state.timer = setTimeout(function () {
      state.timer = null;
      if (!state.lastQuestion) return;
      analyze(state.lastQuestion);
    }, wait);

    // 页面持续抖动（反复触发 debounce）时，最迟 4s 也要出结果
    if (!state.maxTimer) {
      state.maxTimer = setTimeout(function () {
        state.maxTimer = null;
        if (!state.analyzing && state.lastQuestion && !state.lastResult) {
          analyze(q);
        }
      }, Math.max(4000, wait));
    }
  }

  function startWatching() {
    if (state.started) return;
    state.started = true;

    try {
      state.observer = new MutationObserver(
        QB.debounce(function () {
          scheduleInspect(250);
        }, 350)
      );
      state.observer.observe(document.documentElement, {
        childList: true,
        subtree: true,
        characterData: true
      });
    } catch (err) {
      QB.warn('MutationObserver 不可用', err);
    }

    state.pollTimer = setInterval(function () {
      if (document.hidden) return;
      scheduleInspect(0);
    }, 1600);

    document.addEventListener('visibilitychange', function () {
      if (!document.hidden) scheduleInspect(200);
    });
  }

  function stopWatching() {
    if (state.observer) state.observer.disconnect();
    state.observer = null;
    if (state.pollTimer) clearInterval(state.pollTimer);
    state.pollTimer = null;
    if (state.timer) clearTimeout(state.timer);
    state.timer = null;
    state.started = false;
  }

  QB.Quiz = {
    init: function (adapter) {
      state.adapter = adapter;
      state.enabled = !!QB.settings.quiz.enabled;
      state.lastAiSnapshot = JSON.stringify(QB.settings.ai || {});
      refreshPanelChrome();
      if (state.enabled) {
        startWatching();
        scheduleInspect(600);
      }
    },

    updateSettings: function (adapter) {
      if (adapter) state.adapter = adapter;
      const enabled = !!QB.settings.quiz.enabled;
      const aiSnapshot = JSON.stringify(QB.settings.ai || {});
      const aiChanged = state.lastAiSnapshot !== undefined && state.lastAiSnapshot !== aiSnapshot;
      state.lastAiSnapshot = aiSnapshot;

      if (enabled !== state.enabled) {
        state.enabled = enabled;
        if (enabled) {
          startWatching();
          scheduleInspect(300);
        } else {
          stopWatching();
          clearHighlight();
          if (panelAvailable()) {
            QB.Panel.clearAnswer();
            QB.Panel.setStatus('答题已关闭', '');
          }
        }
      }

      // 用户刚改完 AI 配置（例如补上 Key）时，自动重试当前题
      if (
        aiChanged &&
        enabled &&
        state.lastQuestion &&
        !state.lastResult &&
        !state.analyzing &&
        QB.settings.quiz.autoAnalyze
      ) {
        state.attemptSig = '';
        analyze(state.lastQuestion);
      }

      refreshPanelChrome();
    },

    reanalyze: function () {
      if (!state.enabled) {
        showError('答题功能已关闭，可在面板中开启或按 Alt+Q');
        return;
      }
      if (!state.lastQuestion) {
        if (panelAvailable()) QB.Panel.setStatus('未识别到题目，尝试截图识别…', 'loading');
        analyzeByScreenshot(null);
        return;
      }
      state.lastResult = null;
      clearHighlight();
      state.attemptSig = '';
      analyze(state.lastQuestion, { force: true });
    },

    getQuestion: function () {
      return state.lastQuestion;
    }
  };
})();
