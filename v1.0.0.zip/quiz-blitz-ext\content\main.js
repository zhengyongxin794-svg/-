/**
 * content 入口：装配面板 / 答题 / 视频三个模块，处理快捷键与消息。
 */
(function () {
  'use strict';

  const QB = window.QB;
  let adapter = null;

  function ensurePanel(expand) {
    if (!QB.isTopFrame) return;
    QB.Panel.init();
    QB.Panel.onAction(handlePanelAction);
    if (expand) QB.Panel.expand();
  }

  function copyAnswer() {
    const text = QB.Panel.currentAnswerText();
    if (!text) return;
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).catch(function () {});
    } else {
      const ta = document.createElement('textarea');
      ta.value = text;
      document.body.appendChild(ta);
      ta.select();
      try {
        document.execCommand('copy');
      } catch (err) {
        /* ignore */
      }
      ta.remove();
    }
  }

  function handlePanelAction(action) {
    switch (action) {
      case 'reanalyze':
        QB.Quiz.reanalyze();
        break;
      case 'copy':
        copyAnswer();
        break;
      case 'collapse':
        QB.Panel.collapse();
        break;
      case 'hide':
        QB.Panel.hideCompletely();
        break;
      case 'options':
        QB.send({ type: 'QB_OPEN_OPTIONS' });
        break;
      case 'toggle-quiz':
        toggleQuiz();
        break;
      case 'show-panel':
        QB.Panel.expand();
        break;
      case 'speed-up':
        QB.Video.step(1);
        break;
      case 'speed-down':
        QB.Video.step(-1);
        break;
      case 'next-video':
        QB.Video.next();
        break;
      default:
        break;
    }
  }

  function toggleQuiz() {
    const next = !QB.settings.quiz.enabled;
    QB.saveSettings({ quiz: Object.assign({}, QB.settings.quiz, { enabled: next }) });
    QB.Quiz.updateSettings(adapter);
    ensurePanel(true);
    QB.Panel.setStatus(next ? '答题已开启' : '答题已关闭', next ? 'ok' : '');
  }

  function handleBroadcast(msg) {
    const channel = msg.channel;
    const payload = msg.payload || {};

    if (channel === 'video-cmd') {
      if (payload.cmd === 'speed-up') QB.Video.step(1);
      else if (payload.cmd === 'speed-down') QB.Video.step(-1);
      else if (payload.cmd === 'set-speed') QB.Video.setSpeed(payload.value);
      else if (payload.cmd === 'next') QB.Video.next();
      return;
    }
    if (channel === 'quiz-reanalyze') {
      QB.Quiz.reanalyze();
      return;
    }
    if (channel === 'toggle-quiz') {
      toggleQuiz();
      return;
    }
    if (channel === 'panel-show') {
      ensurePanel(true);
      return;
    }
    if (channel === 'panel-hide') {
      if (QB.isTopFrame) QB.Panel.hideCompletely();
    }
  }

  function handleTopDisplay(msg) {
    if (!QB.isTopFrame) return;
    const channel = msg.channel;
    const data = msg.data || {};

    if (channel === 'video-state') {
      QB.Panel.setVideo(data);
      return;
    }
    if (channel === 'quiz-status') {
      if (data.text) QB.Panel.setStatus(data.text, data.kind || '');
      return;
    }
    if (channel === 'quiz-result') {
      ensurePanel(true);
      QB.Panel.setBadge(data.typeName);
      QB.Panel.setStem(data.stem);
      QB.Panel.setAnswer({
        answerText: data.answerText,
        isLong: !!data.isLong,
        hints: data.hints || [],
        explanation: data.explanation || ''
      });
      QB.Panel.setStatus(data.status || '分析完成（来自内嵌框架）', 'ok');
    }
  }

  function bindHotkeys() {
    window.addEventListener(
      'keydown',
      function (event) {
        if (!event.altKey || event.ctrlKey || event.metaKey) return;
        const code = event.code;

        if (code === 'KeyQ') {
          event.preventDefault();
          if (!QB.isTopFrame) return;
          if (!QB.Panel.isMounted() || QB.Panel.isCollapsed()) {
            ensurePanel(true);
          } else {
            QB.Panel.collapse();
          }
          return;
        }
        if (code === 'KeyR') {
          event.preventDefault();
          ensurePanel(true);
          QB.Quiz.reanalyze();
          return;
        }
        if (code === 'Equal' || code === 'NumpadAdd') {
          event.preventDefault();
          QB.Video.step(1);
          return;
        }
        if (code === 'Minus' || code === 'NumpadSubtract') {
          event.preventDefault();
          QB.Video.step(-1);
          return;
        }
        if (code === 'KeyN' && event.shiftKey) {
          event.preventDefault();
          QB.Video.next();
        }
      },
      true
    );
  }

  function refreshAdapterAndModules() {
    adapter = QB.matchAdapter(location.hostname, QB.settings.customAdapters);
    QB.Quiz.updateSettings(adapter);
    QB.Video.updateSettings(adapter);
  }

  function boot() {
    QB.loadSettings().then(function () {
      adapter = QB.matchAdapter(location.hostname, QB.settings.customAdapters);

      if (QB.isTopFrame) {
        // 面板按需挂载：识别到题目、按 Alt+Q 或从弹窗触发时才出现，避免干扰普通页面
        QB.Panel.onAction(handlePanelAction);
      }

      QB.Quiz.init(adapter);
      QB.Video.init(adapter);
      bindHotkeys();

      QB.onSettingsChange(function () {
        refreshAdapterAndModules();
      });

      QB.log('boot ok', location.hostname, adapter.id);
    });
  }

  if (QB.isTopFrame) {
    chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
      if (!msg) return;
      if (msg.type === 'QB_BROADCAST') {
        handleBroadcast(msg);
        sendResponse({ ok: true });
        return;
      }
      if (msg.type === 'QB_TOP_DISPLAY') {
        handleTopDisplay(msg);
        sendResponse({ ok: true });
      }
    });
  } else {
    chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
      if (!msg) return;
      if (msg.type === 'QB_BROADCAST') {
        handleBroadcast(msg);
        sendResponse({ ok: true });
      }
    });
  }

  boot();
})();
