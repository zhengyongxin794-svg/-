/**
 * 悬浮面板（Shadow DOM 隔离，避免被页面样式污染）。
 * 仅在顶层 frame 挂载；子 frame 的解析结果通过 background 转发到顶层显示。
 */
(function () {
  'use strict';

  const QB = window.QB;

  const STYLE = `
  :host { all: initial; }
  * { box-sizing: border-box; }
  .wrap {
    position: fixed; z-index: 2147483647;
    width: 332px; max-height: 62vh;
    display: flex; flex-direction: column;
    background: rgba(17,19,32,.96);
    color: #e7e9f3;
    border: 1px solid rgba(120,130,255,.28);
    border-radius: 14px;
    box-shadow: 0 12px 40px rgba(0,0,0,.45), 0 0 0 1px rgba(255,255,255,.04) inset;
    font: 13px/1.5 -apple-system, "Segoe UI", "Microsoft YaHei", sans-serif;
    backdrop-filter: blur(10px);
    overflow: hidden;
    user-select: none;
  }
  .wrap.collapsed { display: none; }
  header {
    display: flex; align-items: center; gap: 6px;
    padding: 9px 10px;
    background: linear-gradient(90deg, rgba(99,102,241,.28), rgba(34,211,238,.12));
    border-bottom: 1px solid rgba(255,255,255,.07);
    cursor: move;
  }
  .dot { width: 8px; height: 8px; border-radius: 50%; background: #64748b; flex: 0 0 auto; }
  .dot.loading { background: #fbbf24; animation: pulse 1s infinite; }
  .dot.ok { background: #34d399; }
  .dot.err { background: #f87171; }
  @keyframes pulse { 0%,100% { opacity: 1 } 50% { opacity: .25 } }
  .title { font-weight: 600; font-size: 13px; letter-spacing: .2px; }
  .badge {
    font-size: 11px; padding: 1px 6px; border-radius: 999px;
    background: rgba(99,102,241,.25); color: #c7d2fe; border: 1px solid rgba(129,140,248,.35);
  }
  .spacer { flex: 1; }
  button {
    font: inherit; color: inherit; background: rgba(255,255,255,.06);
    border: 1px solid rgba(255,255,255,.1); border-radius: 8px;
    cursor: pointer; padding: 2px 7px; line-height: 18px;
  }
  button:hover { background: rgba(255,255,255,.14); }
  button.ghost { background: transparent; border-color: transparent; padding: 2px 5px; color: #aab0c5; }
  button.ghost:hover { color: #fff; background: rgba(255,255,255,.1); }
  .body { padding: 10px 12px 8px; overflow-y: auto; }
  .status { font-size: 12px; color: #9aa3bd; min-height: 18px; word-break: break-word; }
  .status.ok { color: #86efac; }
  .status.err { color: #fca5a5; }
  .stem {
    font-size: 11.5px; color: #8b93ad; margin: 6px 0 2px;
    max-height: 54px; overflow: hidden; display: -webkit-box;
    -webkit-line-clamp: 3; -webkit-box-orient: vertical; word-break: break-word;
  }
  .answer {
    margin: 8px 0 4px; padding: 9px 10px;
    border-radius: 10px; font-size: 18px; font-weight: 700; letter-spacing: .5px;
    background: linear-gradient(135deg, rgba(52,211,153,.16), rgba(99,102,241,.16));
    border: 1px solid rgba(52,211,153,.28); color: #a7f3d0;
    word-break: break-word; user-select: text;
  }
  .answer.text { font-size: 14px; font-weight: 500; line-height: 1.55; color: #d1fae5; }
  .hints { margin-top: 6px; display: flex; flex-direction: column; gap: 4px; user-select: text; }
  .hint {
    display: flex; gap: 6px; padding: 5px 8px; border-radius: 8px;
    background: rgba(255,255,255,.04); font-size: 12px; color: #c3c9dc;
    border: 1px solid transparent; word-break: break-word;
  }
  .hint.hit {
    background: rgba(52,211,153,.13); border-color: rgba(52,211,153,.35); color: #d1fae5;
  }
  .hint b { color: #a5b4fc; flex: 0 0 auto; }
  .explain {
    margin-top: 8px; padding-top: 8px; border-top: 1px dashed rgba(255,255,255,.1);
    font-size: 12px; color: #9aa3bd; white-space: pre-wrap; word-break: break-word;
    user-select: text; max-height: 150px; overflow-y: auto;
  }
  .videoRow {
    margin-top: 9px; padding-top: 8px; border-top: 1px dashed rgba(255,255,255,.1);
    display: flex; align-items: center; gap: 6px; font-size: 12px; color: #9aa3bd;
  }
  .videoRow .vlabel { flex: 1; }
  .videoRow .speed { min-width: 46px; text-align: center; color: #c7d2fe; font-weight: 600; }
  footer {
    display: flex; align-items: center; gap: 8px;
    padding: 7px 12px; border-top: 1px solid rgba(255,255,255,.07);
    font-size: 11px; color: #6f778f;
  }
  footer .tag { flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .link { background: none; border: none; color: #818cf8; cursor: pointer; padding: 0; font-size: 11px; }
  .link:hover { color: #a5b4fc; }
  .ball {
    position: fixed; z-index: 2147483647; width: 46px; height: 46px; border-radius: 50%;
    display: flex; flex-direction: column; align-items: center; justify-content: center;
    background: linear-gradient(135deg, #6366f1, #22d3ee);
    color: #fff; font: 700 16px/1 -apple-system, "Segoe UI", sans-serif;
    box-shadow: 0 6px 22px rgba(99,102,241,.55); cursor: pointer;
    border: 2px solid rgba(255,255,255,.22); user-select: none;
  }
  .ball .s { font-size: 9px; font-weight: 600; opacity: .9; margin-top: 2px; }
  .ball.hidden { display: none; }
  `;

  let host = null;
  let shadow = null;
  let refs = {};
  let actionHandler = null;
  let dragState = null;

  function el(tag, cls, text) {
    const node = document.createElement(tag);
    if (cls) node.className = cls;
    if (text != null) node.textContent = text;
    return node;
  }

  function positionFromSettings() {
    const cfg = (QB.settings.quiz.panel || {});
    const pos = { x: cfg.x, y: cfg.y };
    if (pos.x == null || pos.y == null) {
      pos.x = window.innerWidth - 332 - 22;
      pos.y = 96;
    }
    pos.x = Math.max(4, Math.min(pos.x, window.innerWidth - 120));
    pos.y = Math.max(4, Math.min(pos.y, window.innerHeight - 80));
    return pos;
  }

  function applyPosition(pos) {
    if (!refs.wrap) return;
    refs.wrap.style.left = pos.x + 'px';
    refs.wrap.style.top = pos.y + 'px';
    refs.wrap.style.right = 'auto';
    if (refs.ball) {
      refs.ball.style.left = pos.x + 'px';
      refs.ball.style.top = pos.y + 'px';
    }
  }

  function persistPosition() {
    if (!refs.wrap) return;
    const x = parseInt(refs.wrap.style.left, 10);
    const y = parseInt(refs.wrap.style.top, 10);
    if (Number.isNaN(x) || Number.isNaN(y)) return;
    const panelCfg = Object.assign({}, QB.settings.quiz.panel, { x: x, y: y });
    QB.saveSettings({ quiz: Object.assign({}, QB.settings.quiz, { panel: panelCfg }) });
  }

  const persistPositionDebounced = QB.debounce(persistPosition, 400);

  function startDrag(event) {
    if (event.button !== 0) return;
    const target = event.target;
    if (target && target.closest && target.closest('button')) return;
    const wrap = refs.wrap;
    const rect = wrap.getBoundingClientRect();
    dragState = {
      offsetX: event.clientX - rect.left,
      offsetY: event.clientY - rect.top
    };
    event.preventDefault();
    window.addEventListener('pointermove', onDrag, true);
    window.addEventListener('pointerup', endDrag, true);
  }

  function onDrag(event) {
    if (!dragState) return;
    const x = Math.max(4, Math.min(event.clientX - dragState.offsetX, window.innerWidth - 80));
    const y = Math.max(4, Math.min(event.clientY - dragState.offsetY, window.innerHeight - 48));
    applyPosition({ x: x, y: y });
  }

  function endDrag() {
    if (!dragState) return;
    dragState = null;
    window.removeEventListener('pointermove', onDrag, true);
    window.removeEventListener('pointerup', endDrag, true);
    persistPositionDebounced();
  }

  function emit(action, detail) {
    if (actionHandler) {
      try {
        actionHandler(action, detail || {});
      } catch (err) {
        QB.warn('panel action error', err);
      }
    }
  }

  function build() {
    host = document.createElement('div');
    host.id = 'qb-panel-host';
    host.style.cssText = 'all:initial;position:fixed;inset:0;width:0;height:0;pointer-events:none;z-index:2147483647;';
    shadow = host.attachShadow({ mode: 'closed' });

    const style = document.createElement('style');
    style.textContent = STYLE;

    const wrap = el('div', 'wrap');
    wrap.style.pointerEvents = 'auto';

    const header = el('header');
    const dot = el('span', 'dot');
    const title = el('span', 'title', '刷题助手');
    const badge = el('span', 'badge', '—');
    badge.hidden = true;
    const spacer = el('div', 'spacer');
    const btnRe = el('button', 'ghost', '↻');
    btnRe.title = '重新分析（Alt+R）';
    btnRe.dataset.act = 'reanalyze';
    const btnCopy = el('button', 'ghost', '⧉');
    btnCopy.title = '复制答案';
    btnCopy.dataset.act = 'copy';
    const btnFold = el('button', 'ghost', '—');
    btnFold.title = '收起';
    btnFold.dataset.act = 'collapse';
    const btnClose = el('button', 'ghost', '×');
    btnClose.title = '隐藏面板（Alt+Q 唤起）';
    btnClose.dataset.act = 'hide';

    header.append(dot, title, badge, spacer, btnRe, btnCopy, btnFold, btnClose);

    const body = el('div', 'body');
    const status = el('div', 'status', '等待题目…');
    const stem = el('div', 'stem');
    stem.hidden = true;
    const answer = el('div', 'answer');
    answer.hidden = true;
    const hints = el('div', 'hints');
    const explain = el('div', 'explain');
    explain.hidden = true;

    const videoRow = el('div', 'videoRow');
    videoRow.hidden = true;
    const vlabel = el('span', 'vlabel', '视频倍速');
    const btnMinus = el('button', '', '−');
    btnMinus.dataset.act = 'speed-down';
    const speedVal = el('span', 'speed', '8.0x');
    const btnPlus = el('button', '', '+');
    btnPlus.dataset.act = 'speed-up';
    const btnNext = el('button', '', '下一段');
    btnNext.dataset.act = 'next-video';
    videoRow.append(vlabel, btnMinus, speedVal, btnPlus, btnNext);

    body.append(status, stem, answer, hints, explain, videoRow);

    const footer = el('footer');
    const tag = el('span', 'tag', '未配置模型');
    const btnOptions = el('button', 'link', '设置');
    btnOptions.dataset.act = 'options';
    const btnToggle = el('button', 'link', '关闭答题');
    btnToggle.dataset.act = 'toggle-quiz';
    footer.append(tag, btnOptions, btnToggle);

    wrap.append(header, body, footer);

    const ball = el('div', 'ball');
    ball.style.pointerEvents = 'auto';
    const ballIcon = el('span', '', '⚡');
    const ballSpeed = el('span', 's', '');
    ball.append(ballIcon, ballSpeed);
    ball.classList.add('hidden');

    shadow.append(style, wrap, ball);
    (document.documentElement || document.body).appendChild(host);

    refs = {
      wrap: wrap, header: header, dot: dot, badge: badge, status: status,
      stem: stem, answer: answer, hints: hints, explain: explain,
      videoRow: videoRow, speedVal: speedVal, tag: tag, ball: ball,
      ballSpeed: ballSpeed, btnToggle: btnToggle
    };

    header.addEventListener('pointerdown', startDrag);
    ball.addEventListener('pointerdown', function (event) {
      const rect = ball.getBoundingClientRect();
      dragState = { offsetX: event.clientX - rect.left, offsetY: event.clientY - rect.top, moved: false };
      event.preventDefault();
      window.addEventListener('pointermove', onBallDrag, true);
      window.addEventListener('pointerup', function up() {
        window.removeEventListener('pointermove', onBallDrag, true);
        window.removeEventListener('pointerup', up, true);
        if (dragState && dragState.moved) {
          persistPositionDebounced();
          dragState = null;
          return;
        }
        dragState = null;
        emit('show-panel');
      }, true);
    });

    function onBallDrag(event) {
      if (!dragState) return;
      dragState.moved = true;
      const x = Math.max(4, Math.min(event.clientX - dragState.offsetX, window.innerWidth - 50));
      const y = Math.max(4, Math.min(event.clientY - dragState.offsetY, window.innerHeight - 50));
      applyPosition({ x: x, y: y });
    }

    wrap.addEventListener('click', handleClick);
    ball.addEventListener('click', function (event) {
      event.stopPropagation();
    });
    [wrap, ball].forEach(function (node) {
      node.addEventListener('pointerdown', function (event) {
        event.stopPropagation();
      });
      node.addEventListener('keydown', function (event) {
        event.stopPropagation();
      });
    });

    applyPosition(positionFromSettings());
  }

  function handleClick(event) {
    const target = event.target;
    const btn = target && target.closest ? target.closest('[data-act]') : null;
    if (!btn) return;
    event.preventDefault();
    event.stopPropagation();
    emit(btn.dataset.act);
  }

  QB.Panel = {
    init: function () {
      if (!QB.isTopFrame) return;
      if (host) return;
      build();
      const cfg = QB.settings.quiz.panel || {};
      if (cfg.hidden) {
        refs.wrap.classList.add('collapsed');
        refs.ball.classList.add('hidden');
      } else if (cfg.collapsed) {
        refs.wrap.classList.add('collapsed');
        refs.ball.classList.remove('hidden');
      }
    },

    onAction: function (fn) {
      actionHandler = fn;
    },

    isMounted: function () {
      return !!host;
    },

    setStatus: function (text, kind) {
      if (!refs.status) return;
      refs.status.textContent = text;
      refs.status.className = 'status' + (kind ? ' ' + kind : '');
      if (refs.dot) refs.dot.className = 'dot' + (kind ? ' ' + kind : '');
    },

    setBadge: function (text) {
      if (!refs.badge) return;
      if (!text) {
        refs.badge.hidden = true;
        return;
      }
      refs.badge.hidden = false;
      refs.badge.textContent = text;
    },

    setStem: function (text) {
      if (!refs.stem) return;
      if (!text) {
        refs.stem.hidden = true;
        refs.stem.textContent = '';
        return;
      }
      refs.stem.hidden = false;
      refs.stem.textContent = text;
    },

    /** @param {{answerText:string, isLong:boolean, hints:Array, explanation:string}} data */
    setAnswer: function (data) {
      if (!refs.answer) return;
      const answer = data.answerText || '';
      refs.answer.hidden = !answer;
      refs.answer.textContent = answer;
      refs.answer.className = 'answer' + (data.isLong ? ' text' : '');

      refs.hints.textContent = '';
      (data.hints || []).forEach(function (hint) {
        const row = el('div', 'hint' + (hint.hit ? ' hit' : ''));
        const b = el('b', '', hint.label);
        const t = el('span', '', hint.text);
        row.append(b, t);
        refs.hints.appendChild(row);
      });

      const showExplain = QB.settings.quiz.showExplanation && data.explanation;
      refs.explain.hidden = !showExplain;
      refs.explain.textContent = showExplain ? data.explanation : '';
    },

    clearAnswer: function () {
      if (!refs.answer) return;
      refs.answer.hidden = true;
      refs.answer.textContent = '';
      refs.hints.textContent = '';
      refs.explain.hidden = true;
      refs.explain.textContent = '';
    },

    setVideo: function (state) {
      if (!refs.videoRow) return;
      const visible = !!(state && state.visible);
      refs.videoRow.hidden = !visible;
      if (!visible) {
        if (refs.ballSpeed) refs.ballSpeed.textContent = '';
        return;
      }
      const speed = Number(state.speed || 1);
      refs.speedVal.textContent = speed.toFixed(1) + 'x';
      if (refs.ballSpeed) refs.ballSpeed.textContent = speed.toFixed(0) + 'x';
    },

    setModelTag: function (text) {
      if (refs.tag) refs.tag.textContent = text;
    },

    setQuizEnabled: function (enabled) {
      if (!refs.btnToggle) return;
      refs.btnToggle.textContent = enabled ? '关闭答题' : '开启答题';
    },

    show: function (revealBall) {
      if (!refs.wrap) return;
      if (QB.settings.quiz.panel.collapsed || revealBall === 'ball') {
        refs.wrap.classList.add('collapsed');
        refs.ball.classList.remove('hidden');
      } else {
        refs.wrap.classList.remove('collapsed');
        refs.ball.classList.add('hidden');
      }
    },

    collapse: function () {
      if (!refs.wrap) return;
      refs.wrap.classList.add('collapsed');
      refs.ball.classList.remove('hidden');
      const panelCfg = Object.assign({}, QB.settings.quiz.panel, { collapsed: true });
      QB.saveSettings({ quiz: Object.assign({}, QB.settings.quiz, { panel: panelCfg }) });
    },

    expand: function () {
      if (!refs.wrap) return;
      refs.wrap.classList.remove('collapsed');
      refs.ball.classList.add('hidden');
      const panelCfg = Object.assign({}, QB.settings.quiz.panel, { collapsed: false, hidden: false });
      QB.saveSettings({ quiz: Object.assign({}, QB.settings.quiz, { panel: panelCfg }) });
    },

    hideCompletely: function () {
      if (!refs.wrap) return;
      refs.wrap.classList.add('collapsed');
      refs.ball.classList.add('hidden');
      const panelCfg = Object.assign({}, QB.settings.quiz.panel, { hidden: true, collapsed: false });
      QB.saveSettings({ quiz: Object.assign({}, QB.settings.quiz, { panel: panelCfg }) });
    },

    isCollapsed: function () {
      return refs.wrap ? refs.wrap.classList.contains('collapsed') : false;
    },

    toggle: function () {
      if (!refs.wrap) return;
      if (refs.wrap.classList.contains('collapsed')) {
        this.expand();
      } else {
        this.collapse();
      }
    },

    currentAnswerText: function () {
      return refs.answer ? refs.answer.textContent : '';
    }
  };
})();
