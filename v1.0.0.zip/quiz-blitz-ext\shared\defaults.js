/**
 * 公共默认配置。
 * 该文件同时被 content script（按顺序注入）、background（importScripts）、
 * popup 与 options 页面（<script>）加载，保证默认值只有一份。
 */
(function (root) {
  'use strict';

  var STORAGE_KEY = 'qb_settings';
  var CACHE_KEY = 'qb_answer_cache';

  var DEFAULTS = {
    quiz: {
      enabled: true,
      autoAnalyze: true,
      debounceMs: 800,
      screenshotFallback: false,
      showExplanation: true,
      highlightOptions: true,
      minStemLength: 4,
      panel: {
        x: null,
        y: null,
        collapsed: false,
        hidden: false
      }
    },
    ai: {
      baseUrl: 'https://api.openai.com/v1',
      apiKey: '',
      model: 'gpt-4o-mini',
      temperature: 0.2,
      maxTokens: 800,
      jsonMode: true,
      vision: false,
      timeoutMs: 45000,
      extraHeaders: ''
    },
    video: {
      enabled: true,
      autoSpeed: true,
      speed: 8,
      maxSpeed: 15,
      autoNext: true,
      nextDelayMs: 1500,
      enforceRate: true,
      autoPlay: true
    },
    customAdapters: [],
    debug: false
  };

  function clone(value) {
    return JSON.parse(JSON.stringify(value));
  }

  function mergeDeep(base, patch) {
    if (!patch || typeof patch !== 'object') return base;
    Object.keys(patch).forEach(function (key) {
      var pv = patch[key];
      var bv = base[key];
      if (pv === undefined || pv === null) return;
      if (Array.isArray(pv)) {
        base[key] = clone(pv);
      } else if (typeof pv === 'object' && bv && typeof bv === 'object' && !Array.isArray(bv)) {
        mergeDeep(bv, pv);
      } else {
        base[key] = pv;
      }
    });
    return base;
  }

  root.QB = root.QB || {};
  root.QB.STORAGE_KEY = STORAGE_KEY;
  root.QB.CACHE_KEY = CACHE_KEY;
  root.QB.DEFAULTS = DEFAULTS;
  root.QB.clone = clone;
  root.QB.mergeDefaults = function (saved) {
    return mergeDeep(clone(DEFAULTS), saved || {});
  };
})(typeof self !== 'undefined' ? self : this);
