/**
 * 视频引擎：播放器倍速（最高 15x）+ 自动跳转下一段未观看视频。
 * 在任意 frame 中检测到 video 后工作；状态会同步到顶层面板。
 */
(function () {
  'use strict';

  const QB = window.QB;

  const state = {
    adapter: null,
    video: null,
    bound: new WeakSet(),
    tickTimer: null,
    settingRate: false,
    lastNextAt: 0,
    pendingPlayUntil: 0,
    lastReport: '',
    manualStop: false
  };

  function videoSettings() {
    return QB.settings.video || {};
  }

  function clampSpeed(value) {
    const max = Math.min(15, Number(videoSettings().maxSpeed) || 15);
    const v = Number(value);
    if (!Number.isFinite(v)) return 1;
    return Math.min(max, Math.max(1, Math.round(v * 2) / 2));
  }

  function findVideo() {
    const adapter = state.adapter || {};
    const selectors = (adapter.video && adapter.video.player) || ['video'];
    let best = null;
    let bestArea = 0;

    selectors.forEach(function (sel) {
      let nodes = [];
      try {
        nodes = document.querySelectorAll(sel);
      } catch (err) {
        return;
      }
      nodes.forEach(function (node) {
        const video = node.tagName === 'VIDEO' ? node : node.querySelector('video');
        if (!video) return;
        const rect = video.getBoundingClientRect();
        const area = rect.width * rect.height;
        if (area > bestArea && QB.isVisible(video)) {
          best = video;
          bestArea = area;
        }
      });
    });

    if (!best) {
      const fallback = document.querySelector('video');
      if (fallback && QB.isVisible(fallback)) best = fallback;
    }
    return best;
  }

  function updatePanel() {
    if (!QB.isTopFrame) {
      const payload = {
        visible: !!state.video,
        speed: clampSpeed(videoSettings().speed),
        autoNext: !!videoSettings().autoNext,
        playing: state.video ? !state.video.paused : false
      };
      const key = JSON.stringify(payload);
      if (key !== state.lastReport) {
        state.lastReport = key;
        QB.send({ type: 'QB_RELAY_TO_TOP', payload: { channel: 'video-state', data: payload } });
      }
      return;
    }
    if (!QB.Panel.isMounted()) return;
    QB.Panel.setVideo({
      visible: !!state.video,
      speed: clampSpeed(videoSettings().speed)
    });
  }

  function applySpeed(force) {
    const v = state.video;
    const cfg = videoSettings();
    if (!v) return;
    if (!cfg.autoSpeed && !force) return;
    const target = clampSpeed(cfg.speed);
    if (Math.abs(v.playbackRate - target) < 0.01) return;
    try {
      state.settingRate = true;
      v.playbackRate = target;
      v.defaultPlaybackRate = target;
    } catch (err) {
      QB.warn('设置倍速失败', err);
    } finally {
      state.settingRate = false;
    }
  }

  function bindVideo(video) {
    if (!video || state.bound.has(video)) return;
    state.bound.add(video);
    state.video = video;

    video.addEventListener('ended', function () {
      onFinished('ended');
    });

    video.addEventListener('ratechange', function () {
      if (state.settingRate) return;
      if (!videoSettings().enforceRate) return;
      // 平台自己改回 1x 时，下一轮 tick 会重新纠正
    });

    video.addEventListener('loadedmetadata', function () {
      applySpeed(true);
    });

    video.addEventListener('play', function () {
      applySpeed(true);
      updatePanel();
    });

    video.addEventListener('pause', updatePanel);

    QB.log('已绑定 video 元素', video);
    applySpeed(true);
    updatePanel();
  }

  function isCurrentItem(item) {
    const el = item.el;
    const cls = typeof el.className === 'string' ? el.className : '';
    const cls2 = (el.parentElement && typeof el.parentElement.className === 'string') ? el.parentElement.className : '';
    if (/active|current|playing|selected|on(\s|$)/i.test(cls + ' ' + cls2)) return true;
    if (el.getAttribute && el.getAttribute('aria-current')) return true;
    return false;
  }

  function collectItems() {
    const adapter = state.adapter || {};
    const selectors = (adapter.video && adapter.video.listItem) || ['li'];
    const seen = new Set();
    const out = [];

    selectors.forEach(function (sel) {
      let nodes = [];
      try {
        nodes = document.querySelectorAll(sel);
      } catch (err) {
        return;
      }
      Array.prototype.forEach.call(nodes, function (el) {
        if (out.length >= 300) return;
        if (seen.has(el)) return;
        seen.add(el);
        if (!QB.isVisible(el)) return;
        const text = QB.norm(el.innerText || el.textContent || '');
        if (!text || text.length > 160) return;
        out.push({ el: el, text: text });
      });
    });
    return out;
  }

  function classify(items) {
    const cfg = (state.adapter && state.adapter.video) || {};
    const unfinishedKeys = cfg.unfinishedText || [];
    const finishedKeys = cfg.finishedText || [];

    return items.map(function (item) {
      const hasFinished = finishedKeys.some(function (k) { return k && item.text.indexOf(k) !== -1; });
      const hasUnfinished = unfinishedKeys.some(function (k) { return k && item.text.indexOf(k) !== -1; });
      return Object.assign({}, item, {
        finished: hasFinished,
        unfinished: hasUnfinished && !hasFinished
      });
    });
  }

  function clickItem(item) {
    const el = item.el;
    try {
      el.scrollIntoView({ block: 'center', behavior: 'smooth' });
    } catch (err) {
      /* ignore */
    }
    const clickable = el.matches && el.matches('a,button') ? el : el.querySelector('a[href],button') || el;
    try {
      clickable.click();
    } catch (err) {
      QB.warn('点击视频条目失败', err);
    }
  }

  function setStatus(text, kind) {
    if (QB.isTopFrame) {
      if (QB.Panel.isMounted()) QB.Panel.setStatus(text, kind);
      return;
    }
    QB.send({ type: 'QB_RELAY_TO_TOP', payload: { channel: 'quiz-status', data: { text: text, kind: kind || '' } } });
  }

  function tryNativeNextButton() {
    const cfg = (state.adapter && state.adapter.video) || {};
    const btn = QB.pickVisible(cfg.nextButton || []);
    if (btn && !btn.disabled) {
      try {
        btn.click();
        return true;
      } catch (err) {
        /* ignore */
      }
    }
    return false;
  }

  function next(manual) {
    const cfg = videoSettings();
    if (!cfg.enabled) return false;
    const now = Date.now();
    if (!manual && now - state.lastNextAt < 8000) return false;

    const items = classify(collectItems());
    const currentIndex = items.findIndex(isCurrentItem);
    const unfinished = items.filter(function (item) { return item.unfinished; });

    let target = null;
    if (currentIndex >= 0) {
      target = unfinished.find(function (item) {
        return items.indexOf(item) > currentIndex;
      });
    }
    if (!target) {
      target = unfinished.find(function (item) {
        return items.indexOf(item) !== currentIndex;
      });
    }
    if (!target && !manual) {
      const nextSeq = items.find(function (item, index) {
        return index > currentIndex && !item.finished;
      });
      if (nextSeq) target = nextSeq;
    }

    if (!target) {
      if (manual) {
        if (tryNativeNextButton()) {
          state.lastNextAt = now;
          state.pendingPlayUntil = now + 12000;
          setStatus('已点击平台“下一节”按钮', 'ok');
          return true;
        }
        setStatus('没有找到未观看的视频条目', 'err');
      }
      return false;
    }

    state.lastNextAt = now;
    state.pendingPlayUntil = now + 12000;
    clickItem(target);
    setStatus('已跳转到下一段未观看视频：' + target.text.slice(0, 24), 'ok');
    return true;
  }

  function onFinished(reason) {
    const cfg = videoSettings();
    const now = Date.now();
    if (now - state.lastNextAt < 8000) return;
    if (!cfg.enabled || !cfg.autoNext) return;
    setStatus('当前视频已播放完毕，准备跳转…', 'ok');
    setTimeout(function () {
      next(false);
    }, Math.max(300, Number(cfg.nextDelayMs) || 1500));
  }

  function tick() {
    const cfg = videoSettings();
    if (!cfg.enabled) {
      if (state.video) {
        state.video = null;
        updatePanel();
      }
      return;
    }

    if (!state.video || !state.video.isConnected) {
      const found = findVideo();
      if (found) bindVideo(found);
    }

    const video = state.video;
    if (!video) {
      updatePanel();
      return;
    }

    if (cfg.autoSpeed) applySpeed(false);

    if (cfg.autoPlay && state.pendingPlayUntil > Date.now() && video.paused) {
      const p = video.play();
      if (p && typeof p.catch === 'function') p.catch(function () {});
    }

    if (video.duration && isFinite(video.duration) && video.duration > 3) {
      if (video.currentTime >= video.duration - 0.35 && video.paused && !video.ended) {
        onFinished('near-end');
      }
    }

    updatePanel();
  }

  QB.Video = {
    init: function (adapter) {
      state.adapter = adapter;
      if (!state.tickTimer) {
        state.tickTimer = setInterval(tick, 1000);
      }
      tick();
    },

    updateSettings: function (adapter) {
      if (adapter) state.adapter = adapter;
      if (!QB.settings.video.enabled) {
        if (state.video) {
          try {
            state.video.playbackRate = 1;
          } catch (err) {
            /* ignore */
          }
        }
        state.video = null;
      } else if (videoSettings().autoSpeed) {
        applySpeed(true);
      }
      updatePanel();
    },

    setSpeed: function (value) {
      const speed = clampSpeed(value);
      QB.saveSettings({ video: Object.assign({}, QB.settings.video, { speed: speed, autoSpeed: true }) });
      applySpeed(true);
      updatePanel();
      return speed;
    },

    step: function (delta) {
      const current = Number(videoSettings().speed) || 8;
      return this.setSpeed(current + delta);
    },

    next: function () {
      return next(true);
    },

    hasVideo: function () {
      return !!state.video;
    },

    getVideo: function () {
      return state.video;
    }
  };
})();
