/**
 * content script 公共能力：配置读取、消息、DOM 工具。
 */
(function () {
  'use strict';

  const QB = (window.QB = window.QB || {});
  const PREFIX = '[QuizBlitz]';
  const settingsListeners = [];

  QB.isTopFrame = (function () {
    try {
      return window.top === window.self;
    } catch (e) {
      return false;
    }
  })();

  QB.settings = QB.mergeDefaults(null);

  QB.log = function () {
    if (!QB.settings || !QB.settings.debug) return;
    const args = Array.prototype.slice.call(arguments);
    console.log.apply(console, [PREFIX].concat(args));
  };

  QB.warn = function () {
    const args = Array.prototype.slice.call(arguments);
    console.warn.apply(console, [PREFIX].concat(args));
  };

  /** 发送消息到 background，统一返回 Promise<{ok, ...}> */
  QB.send = function (message) {
    return new Promise(function (resolve) {
      try {
        chrome.runtime.sendMessage(message, function (response) {
          if (chrome.runtime.lastError) {
            resolve({ ok: false, error: chrome.runtime.lastError.message });
          } else {
            resolve(response || { ok: false, error: 'background 无响应' });
          }
        });
      } catch (err) {
        resolve({ ok: false, error: String(err) });
      }
    });
  };

  QB.loadSettings = function () {
    return new Promise(function (resolve) {
      chrome.storage.local.get([QB.STORAGE_KEY], function (items) {
        const raw = items && items[QB.STORAGE_KEY];
        QB.settings = QB.mergeDefaults(raw);
        resolve(QB.settings);
      });
    });
  };

  QB.saveSettings = function (patch) {
    QB.settings = QB.mergeDefaults(Object.assign({}, QB.settings, patch));
    const payload = {};
    payload[QB.STORAGE_KEY] = QB.settings;
    return new Promise(function (resolve) {
      chrome.storage.local.set(payload, resolve);
    });
  };

  QB.onSettingsChange = function (fn) {
    if (typeof fn === 'function') settingsListeners.push(fn);
  };

  chrome.storage.onChanged.addListener(function (changes, area) {
    if (area !== 'local' || !changes[QB.STORAGE_KEY]) return;
    const next = changes[QB.STORAGE_KEY].newValue || {};
    QB.settings = QB.mergeDefaults(next);
    settingsListeners.forEach(function (fn) {
      try {
        fn(QB.settings);
      } catch (err) {
        QB.warn('settings listener threw', err);
      }
    });
  });

  /* ---------- 通用工具 ---------- */

  QB.debounce = function (fn, wait) {
    let timer = null;
    const wrapped = function () {
      const args = arguments;
      const ctx = this;
      if (timer) clearTimeout(timer);
      timer = setTimeout(function () {
        timer = null;
        fn.apply(ctx, args);
      }, wait);
    };
    wrapped.cancel = function () {
      if (timer) clearTimeout(timer);
      timer = null;
    };
    wrapped.flush = function () {
      if (!timer) return;
      clearTimeout(timer);
      timer = null;
      fn();
    };
    return wrapped;
  };

  /** FNV-1a 32bit，用于题目指纹 */
  QB.hash = function (str) {
    let h = 0x811c9dc5;
    for (let i = 0; i < str.length; i++) {
      h ^= str.charCodeAt(i);
      h = (h + ((h << 1) + (h << 4) + (h << 7) + (h << 8) + (h << 24))) >>> 0;
    }
    return ('00000000' + h.toString(16)).slice(-8) + '-' + str.length.toString(36);
  };

  QB.norm = function (text) {
    return String(text || '')
      .replace(/\u00a0/g, ' ')
      .replace(/[\t\r]+/g, ' ')
      .replace(/\s{2,}/g, ' ')
      .replace(/\n{2,}/g, '\n')
      .trim();
  };

  QB.isVisible = function (el) {
    if (!el || el.nodeType !== 1) return false;
    if (!el.isConnected) return false;
    const rect = el.getBoundingClientRect();
    if (rect.width < 2 || rect.height < 2) return false;
    const style = window.getComputedStyle(el);
    if (!style) return false;
    if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') return false;
    return true;
  };

  QB.rectDistanceToCenter = function (el) {
    const rect = el.getBoundingClientRect();
    const cx = window.innerWidth / 2;
    const cy = window.innerHeight / 2;
    const dx = rect.left + rect.width / 2 - cx;
    const dy = rect.top + rect.height / 2 - cy;
    return Math.sqrt(dx * dx + dy * dy);
  };

  /** 按选择器数组找到第一个可见元素 */
  QB.pickVisible = function (selectors, root) {
    const scope = root || document;
    for (let i = 0; i < selectors.length; i++) {
      let nodes;
      try {
        nodes = scope.querySelectorAll(selectors[i]);
      } catch (err) {
        continue;
      }
      for (let j = 0; j < nodes.length; j++) {
        if (QB.isVisible(nodes[j])) return nodes[j];
      }
    }
    return null;
  };

  QB.qsaSafe = function (selectors, root) {
    const scope = root || document;
    const result = [];
    (selectors || []).forEach(function (sel) {
      try {
        scope.querySelectorAll(sel).forEach(function (el) {
          if (result.indexOf(el) === -1) result.push(el);
        });
      } catch (err) {
        /* 选择器非法则忽略 */
      }
    });
    return result;
  };

  QB.sleep = function (ms) {
    return new Promise(function (resolve) {
      setTimeout(resolve, ms);
    });
  };
})();
